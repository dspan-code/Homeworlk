"""
Stage 2 的评估：Accuracy + Precision / Recall / F1。

为什么要写这个文件：模板里只有 Evaluate_Accuracy，而 Stage 2 明确要求
多分类的 P/R/F1。二分类的写法在这里是错的，必须带 average='weighted'
（或 'macro' / 'micro'）——报告 §3.3 要解释这个选择。
"""

from local_code.base_class.evaluate import evaluate
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report,
)


class Evaluate_Metrics(evaluate):
    data = None

    def evaluate(self):
        print('evaluating performance...')
        y_true = self.data['true_y']
        y_pred = self.data['pred_y']

        result = {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, average='weighted', zero_division=0),
            'recall': recall_score(y_true, y_pred, average='weighted', zero_division=0),
            'f1': f1_score(y_true, y_pred, average='weighted', zero_division=0),
        }

        print(classification_report(y_true, y_pred, zero_division=0))
        print('Accuracy: %.4f  Precision: %.4f  Recall: %.4f  F1: %.4f' % (
            result['accuracy'], result['precision'], result['recall'], result['f1'],
        ))
        return result
