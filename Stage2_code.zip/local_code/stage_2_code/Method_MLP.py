"""
Stage 2 的 MLP 模型。

你要填的只有 forward() 里那两行。其余是脚手架：
  · train() 是模板里那套五步，原样保留；
  · test() 就是前向 + argmax。

两个必须记住的点：
  1. 输入维度 784 = 28*28，输出维度 10 = 类别数，两边对不上就会 shape error；
  2. 最后一层输出的是 **logits**，不要接 softmax。
     CrossEntropyLoss 内部自带 log_softmax，再接一个 softmax 等于归一化两次。
"""

from local_code.base_class.method import method
import numpy as np
import torch
from torch import nn


class Method_MLP(method, nn.Module):
    data = None
    # 训练轮数。数据是 60k 张图，整批训练一轮大概几秒，30 轮够看到收敛。
    max_epoch = 20
    # 学习率
    learning_rate = 1e-3
    # 隐藏层宽度（消融实验改这里：128 / 256 / 512）
    hidden_dim = 512
    # 每批多少条。None = 整批一次喂进去（模板原样，慢且吃内存）；
    # 设成 128 就是 mini-batch，通常 10 轮就能到 97% 左右。
    batch_size = 128

    def __init__(self, mName, mDescription):
        method.__init__(self, mName, mDescription)
        nn.Module.__init__(self)

        self.fc_layer_1 = nn.Linear(784, self.hidden_dim)   # 784 -> hidden
        self.activation_func_1 = nn.ReLU()
        self.fc_layer_2 = nn.Linear(self.hidden_dim, 10)    # hidden -> 10 类

    def forward(self, x):
        """前向：x 的形状是 (batch, 784)，输出 (batch, 10) 的 logits。"""

        h = self.activation_func_1(self.fc_layer_1(x))   # (batch,784) -> (batch,256)
        return self.fc_layer_2(h)                        # (batch,256) -> (batch,10)

    def train(self, X, y):
        optimizer = torch.optim.Adam(self.parameters(), lr=self.learning_rate)
        loss_function = nn.CrossEntropyLoss()

        # 把 numpy 转成 tensor 只做一次，别在循环里反复转（这是 60k 行，很贵）
        X_tensor = torch.FloatTensor(np.asarray(X))
        y_tensor = torch.LongTensor(np.asarray(y))
        total = X_tensor.shape[0]

        history = []
        for epoch in range(self.max_epoch):
            # 分批：每一轮重新打乱一次，避免模型记住“喂数据的顺序”
            if self.batch_size is None:
                batches = [(X_tensor, y_tensor)]
            else:
                order = torch.randperm(total)
                batches = [
                    (X_tensor[order[start:start + self.batch_size]],
                     y_tensor[order[start:start + self.batch_size]])
                    for start in range(0, total, self.batch_size)
                ]

            epoch_loss = 0.0
            for x_batch, y_batch in batches:
                # 五步，顺序不能乱
                y_pred = self.forward(x_batch)                # 1. 前向
                train_loss = loss_function(y_pred, y_batch)   # 2. 算 loss
                optimizer.zero_grad()                         # 3. 清空上一轮梯度
                train_loss.backward()                         # 4. 反向传播
                optimizer.step()                              # 5. 更新参数
                epoch_loss += float(train_loss.item()) * x_batch.shape[0]

            epoch_loss /= total
            history.append(epoch_loss)

            if epoch % 2 == 0:
                with torch.no_grad():
                    acc = float((self.forward(X_tensor).max(1)[1] == y_tensor).float().mean())
                print('Epoch:', epoch, 'Loss:', round(epoch_loss, 4), 'Train Acc:', round(acc, 4))
        return history

    def test(self, X):
        X_tensor = torch.FloatTensor(np.asarray(X))
        with torch.no_grad():                        # 测试不用建计算图，省内存
            y_logits = self.forward(X_tensor)
        return y_logits.max(1)[1].numpy()            # 取概率最大的那个类

    def run(self):
        print('method running...')
        print('--start training...')
        history = self.train(self.data['train']['X'], self.data['train']['y'])
        self.last_history = history          # 留给脚本存曲线
        print('--start testing...')
        pred_y = self.test(self.data['test']['X'])
        return {'pred_y': pred_y, 'true_y': self.data['test']['y'], 'loss_history': history}
