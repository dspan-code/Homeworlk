"""
Stage 2 的 Setting：用老师给好的 train / test，不做交叉验证。

和模板的区别只有一处：模板是"拿到一份数据再自己切"，
这里是"两份数据分别 load"，所以多一个 dataset_test 属性。
"""

from local_code.base_class.setting import setting


class Setting_Train_Test_Split(setting):
    dataset_test = None

    def load_run_save_evaluate(self):
        print('loading train / test...')
        train_data = self.dataset.load()
        test_data = self.dataset_test.load()

        self.method.data = {'train': train_data, 'test': test_data}
        learned_result = self.method.run()

        self.result.data = learned_result
        self.result.fold_count = None
        self.result.save()

        self.evaluate.data = learned_result
        return self.evaluate.evaluate(), None
