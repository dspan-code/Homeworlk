"""
Stage 2 的数据读取器。

数据格式（ReadMe 里写的）：
  train.csv 60000 行，test.csv 10000 行；
  每行 785 个整数，逗号分隔：
      第 1 个是 label（0~9），后 784 个是 28x28 像素（0~255）。

这个文件是"机械活"，已经替你写好。重点看两处注释：
  · 为什么除以 255
  · 为什么转成 float32
"""

from local_code.base_class.dataset import dataset
import numpy as np


class Dataset_Loader(dataset):
    data = None
    dataset_source_folder_path = None
    dataset_source_file_name = None

    def __init__(self, dName=None, dDescription=None):
        super().__init__(dName, dDescription)

    def load(self):
        print('loading data...')
        # np.loadtxt 一次读完整个文件：每行 785 个数，按逗号切。
        # 60k x 785 的整数，内存大概 300MB 的 float64，所以用 float32 省一半。
        raw = np.loadtxt(
            self.dataset_source_folder_path + self.dataset_source_file_name,
            delimiter=',',
            dtype=np.float32,
        )

        # 第一列是标签，后 784 列是像素
        y = raw[:, 0].astype(np.int64)
        X = raw[:, 1:]

        # 像素值缩到 0~1。不缩也能学，但梯度会大很多，学习率要跟着调；
        # 缩了之后 Adam 用 1e-3 就很稳。
        X = X / 255.0

        print('X shape:', X.shape, ' y shape:', y.shape)
        return {'X': X, 'y': y}
