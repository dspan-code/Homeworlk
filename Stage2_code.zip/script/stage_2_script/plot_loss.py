"""
把 loss_history.txt 画成收敛曲线。

它做的事只有三步：
  1. 读文件：每行是 `epoch,loss`，比如 `0,0.419500`
  2. 画折线：横轴是轮数，纵轴是误差
  3. 存 PNG：默认存到 ../../result/stage_2_result/loss_curve.png

用法（在 script/stage_2_script 里跑）：
    python3 plot_loss.py
    python3 plot_loss.py ../../result/stage_2_result/loss_history.txt

报告 §3.5 要的就是这张图：证明 loss 随训练逐渐下降，模型在收敛。
"""

import os
import sys

import matplotlib

# 不弹窗口，直接存文件（服务器/终端里也能用）
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main():
    source = sys.argv[1] if len(sys.argv) > 1 else '../../result/stage_2_result/loss_history.txt'
    if not os.path.exists(source):
        print('找不到 %s，先跑一次 script_mlp.py' % source)
        return 1

    epochs = []
    losses = []
    with open(source) as handle:
        for line in handle:
            line = line.strip()
            if line == '':
                continue
            epoch, loss = line.split(',')
            epochs.append(int(epoch))
            losses.append(float(loss))

    if len(epochs) == 0:
        print('%s 是空的' % source)
        return 1

    plt.figure(figsize=(6, 4))
    plt.plot(epochs, losses, marker='o', markersize=3, linewidth=1.6, color='#2f6f5e')
    plt.xlabel('Epoch')
    plt.ylabel('Training Loss')
    plt.title('Training Convergence (MLP on MNIST)')
    plt.grid(alpha=0.3)
    plt.tight_layout()

    target = os.path.join(os.path.dirname(source), 'loss_curve.png')
    plt.savefig(target, dpi=150)
    print('已保存：', target)
    print('共 %d 个 epoch，loss 从 %.4f 降到 %.4f' % (len(epochs), losses[0], losses[-1]))
    return 0


if __name__ == '__main__':
    sys.exit(main())
