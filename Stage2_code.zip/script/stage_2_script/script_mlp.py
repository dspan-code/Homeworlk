"""
Stage 2 入口脚本：MNIST 784 维 -> 10 类，MLP。

在 script/stage_2_script/ 里运行：
    PYTHONPATH=../.. python3 script_mlp.py

它做四件事：建对象 -> 装数据 -> 训练测试 -> 存结果 + 算指标。
"""

from local_code.stage_2_code.Dataset_Loader import Dataset_Loader
from local_code.stage_2_code.Method_MLP import Method_MLP
from local_code.stage_2_code.Result_Saver import Result_Saver
from local_code.stage_2_code.Setting_Train_Test_Split import Setting_Train_Test_Split
from local_code.stage_2_code.Evaluate_Metrics import Evaluate_Metrics

import numpy as np
import torch

if __name__ == '__main__':
    # ---- 固定随机种子：同一个种子，结果可复现（报告里要写） ----
    np.random.seed(2)
    torch.manual_seed(2)

    # ---- 1. 数据 ----
    data_folder = '../../data/stage_2_data/'

    train_obj = Dataset_Loader('mnist-train', '60k training instances')
    train_obj.dataset_source_folder_path = data_folder
    train_obj.dataset_source_file_name = 'train.csv'

    test_obj = Dataset_Loader('mnist-test', '10k testing instances')
    test_obj.dataset_source_folder_path = data_folder
    test_obj.dataset_source_file_name = 'test.csv'

    # ---- 2. 模型 ----
    method_obj = Method_MLP('multi-layer perceptron', '784-256-10')

    # ---- 3. 结果保存 ----
    result_obj = Result_Saver('saver', '')
    result_obj.result_destination_folder_path = '../../result/stage_2_result/MLP_'
    result_obj.result_destination_file_name = 'prediction_result'

    # ---- 4. 指标 ----
    evaluate_obj = Evaluate_Metrics('accuracy + P/R/F1', '')

    # ---- 5. 串起来跑 ----
    setting_obj = Setting_Train_Test_Split('train test split', '')
    setting_obj.prepare(train_obj, method_obj, result_obj, evaluate_obj)
    setting_obj.dataset_test = test_obj          # 测试集单独给
    setting_obj.print_setup_summary()

    print('************ Start ************')
    score, _ = setting_obj.load_run_save_evaluate()

    # ---- 6. 把每个 epoch 的 loss 存成文本，报告 §3.5 画图用 ----
    curve_path = '../../result/stage_2_result/loss_history.txt'
    with open(curve_path, 'w') as handle:
        for epoch, loss in enumerate(method_obj.last_history):
            handle.write('%d,%.6f\n' % (epoch, loss))
    print('loss 曲线已写到', curve_path)

    print('************ Overall Performance ************')
    print('Accuracy: %.4f' % score['accuracy'])
    print('Precision: %.4f  Recall: %.4f  F1: %.4f' % (
        score['precision'], score['recall'], score['f1'],
    ))
    print('************ Finish ************')
