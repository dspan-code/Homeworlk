"""
Stage 3 的数据读取器（pickle 版图像数据集）。

和 Stage 1/2 的 Dataset_Loader 是同一个套路：
    继承 base_class.dataset -> 实现 load() -> 返回 {'X': ..., 'y': ...}

区别只在于：「一行一个样本的文本文件」变成「一个 pickle 里装着 train 和 test 两份数据」。

--------------------------------------------------------------------------------
Stage 3 数据长什么样（已用 pickle.load 实测确认，和 ReadMe.txt 一致）
--------------------------------------------------------------------------------
每个数据集是 data/stage_3_data/ 下的一个 pickle 文件：
    ORL    MNIST    CIFAR

load 出来的对象是这样一棵 dict：
    {
      'train': [ {'image': <图像矩阵>, 'label': <int>}, ... ],   # 老师已切分好
      'test':  [ {'image': <图像矩阵>, 'label': <int>}, ... ],
    }

实测统计：

    数据集    train / test    单张图像形状        dtype    标签范围
    MNIST     60000 / 10000    (28, 28)           float64  0 .. 9
    ORL       360 / 40         (112, 92, 3)       uint8    1 .. 40
    CIFAR     50000 / 10000    (32, 32, 3)        uint8    0 .. 9

注意三件事：
  1. 训练集和测试集老师已经分好了，**Stage 3 不要再做 train_test_split 或 KFold**。
  2. MNIST 的 dtype 是 float64（值在 0~255），ORL / CIFAR 是 uint8。
     不管哪个，读进来后统一做 /255.0 归一化 + 转 float32。
  3. ORL 的标签是 1~40（从 1 开始），不是 0~39。
     PyTorch 的 CrossEntropyLoss 要求类别下标必须落在 [0, C-1]，
     所以 ORL 必须把标签减 1。MNIST / CIFAR 是 0 开头的，不用动。
     这个开关做成了 label_offset 参数，做 ORL 时设 label_offset=1。

--------------------------------------------------------------------------------
三个数据集各自的调用参数（本类通用，不用改代码）
--------------------------------------------------------------------------------
    MNIST: file_name='MNIST',  flatten=False, channel=None, label_offset=0
    ORL:   file_name='ORL',    flatten=False, channel=0,    label_offset=1
    CIFAR: file_name='CIFAR',  flatten=False, channel=None, label_offset=0

  · flatten=True  -> X 返回 (N, 784) 平铺向量，给 MLP 用
    flatten=False -> X 返回 (N, C, H, W) 四维数组，给 CNN 用   ← Stage 3 走这条
  · channel       -> 只取第几个颜色通道。ORL 三个通道值完全一样（灰度图复制成三份），
                     取一个通道就够，省 3 倍内存，且不影响结果。
  · label_offset  -> 标签统一减掉这个数，把起始值拉回 0。
"""

from local_code.base_class.dataset import dataset
import pickle
import numpy as np


class Dataset_Loader(dataset):
    data = None
    dataset_source_folder_path = None
    dataset_source_file_name = None

    # ---------------------------------------------------------------------
    # 三个开关决定「读出来的 X 是什么形状」「标签从几开始」
    # ---------------------------------------------------------------------
    def __init__(self, dName=None, dDescription=None,
                 flatten=False, channel=None, label_offset=0):
        super().__init__(dName, dDescription)
        self.flatten = flatten
        self.channel = channel
        self.label_offset = label_offset

    # ---------------------------------------------------------------------
    # 把一个 'train' 或 'test' 列表整理成 numpy 数组
    # ---------------------------------------------------------------------
    def _convert(self, instance_list):
        # 每张图先 np.asarray 统一成 array（pickle 里本来就是 array，这里是保险）
        images = [np.asarray(instance['image']) for instance in instance_list]

        # 转 float32 再 /255：
        #   · 不除 255 的话输入是 0~255 的大数，梯度会爆，学习率得压到很小
        #   · 用 float32 而非默认 float64，内存减半，CNN 也只吃 float32
        X = np.stack(images).astype(np.float32) / 255.0

        y = np.array([instance['label'] for instance in instance_list], dtype=np.int64)

        # 标签整体平移到 0 开始（ORL 用得上）
        if self.label_offset:
            y = y - self.label_offset

        # 只保留某一个颜色通道。X 现在是 (N, H, W, C)，取最后一维的第 channel 个。
        if self.channel is not None:
            X = X[..., self.channel]

        # 统一整理成 PyTorch 卷积层要求的 (N, C, H, W)：
        if not self.flatten:
            if X.ndim == 3:                               # (N, H, W) 单通道
                X = X[:, None, :, :]                      # -> (N, 1, H, W)
            elif X.ndim == 4 and X.shape[-1] in (1, 3):   # (N, H, W, C)
                X = np.transpose(X, (0, 3, 1, 2))         # -> (N, C, H, W)
        else:
            X = X.reshape(X.shape[0], -1)                 # (N, ...) -> (N, D)

        # .copy() 让数组连续：np.transpose 出来的是「视图」，不连续，
        # 后面 torch.FloatTensor(np.asarray(X)) 可能会报警告或变慢。
        return np.ascontiguousarray(X), y

    # ---------------------------------------------------------------------
    # 抽象方法 load()：把整个 pickle 读进来
    #
    # 返回结构直接就是 base_class 里 Setting 期望的 method.data 格式：
    #     {'train': {'X': ..., 'y': ...}, 'test': {'X': ..., 'y': ...}}
    # 所以 Stage 3 的 Setting 可以写得很简单。
    # ---------------------------------------------------------------------
    def load(self):
        print('loading data...')
        path = self.dataset_source_folder_path + self.dataset_source_file_name

        with open(path, 'rb') as handle:
            raw = pickle.load(handle)

        X_train, y_train = self._convert(raw['train'])
        X_test, y_test = self._convert(raw['test'])

        print('train X:', X_train.shape, ' train y:', y_train.shape,
              ' test X:', X_test.shape, ' test y:', y_test.shape)
        print('label range: [%d, %d]' % (y_train.min(), y_train.max()))

        return {
            'train': {'X': X_train, 'y': y_train},
            'test': {'X': X_test, 'y': y_test},
        }
