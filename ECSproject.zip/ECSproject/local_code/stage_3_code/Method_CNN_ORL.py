"""
Stage 3 的 CNN 模型（ORL 人脸识别，40 类）。

这个文件用的是**你自己设计的结构**：
    · CNNlayer     —— 卷积部分：3 个 Conv-BN-ReLU-Pool 块
    · Estimatelayer —— 分类头：Dropout -> 全局平均池化 -> Flatten -> Linear
    · CNNlayerParameter —— 把超参集中在一处，算好 padding 后建出两个部分

================================================================================
整体数据流（每一层的形状变化，报告里可以直接用这张表）
================================================================================

    输入                 (N, 1, 112, 92)     ORL 灰度人脸，已归一化到 0~1
    ------------------------------------------------------------------
    Conv2d(1 -> 10)      (N, 10, 112, 92)    k=3 p=1 保持尺寸
    BatchNorm + ReLU     (N, 10, 112, 92)
    MaxPool2d(2)         (N, 10,  56,  46)   减半
    ------------------------------------------------------------------
    Conv2d(10 -> 10)     (N, 10,  56,  46)
    BatchNorm + ReLU     (N, 10,  56,  46)
    MaxPool2d(2)         (N, 10,  28,  23)   减半
    ------------------------------------------------------------------
    Conv2d(10 -> 24)     (N, 24,  28,  23)
    BatchNorm + ReLU     (N, 24,  28,  23)
    MaxPool2d(2)         (N, 24,  14,  11)   减半
    ------------------------------------------------------------------
    Dropout(0.5)         (N, 24,  14,  11)   训练时随机丢一半
    AdaptiveAvgPool2d(1) (N, 24,   1,   1)   每个通道取平均 -> 24 维
    Flatten              (N, 24)
    Linear(24 -> 40)     (N, 40)             40 个人各自的得分（logits）

================================================================================
三个必须知道的坑（这个文件都处理了）
================================================================================

【坑 1】self.train() / self.eval() 会崩
    base_class.method 要求实现 train(self, X, y)，它覆盖了 nn.Module.train()。
    而 nn.Module.eval() 内部就是调 self.train(False)，所以两个都不能用。
    解法：自己写 _set_training(mode) 直接改底层标志位。

【坑 2】Dropout 和 BatchNorm 在训练/测试时行为不同
    · 训练：Dropout 随机丢、BatchNorm 用当前 batch 的统计量
    · 测试：Dropout 关闭、BatchNorm 用训练累积的滑动平均
    不切模式的话，同一张图测两次结果都不一样。
    所以训练前 _set_training(True)，测试前 _set_training(False)。

【坑 3】ORL 只有 360 张训练图、40 类，极易过拟合
    · Dropout 用 0.5（不是 0.2）
    · 分类头用全局平均池化（1000 参数，不是摊平的 147880 参数）
    · weight_decay 加到 1e-3
    · 一定要画训练/测试两条曲线看有没有过拟合
"""

from local_code.base_class.method import method
import numpy as np
import torch
from torch import nn


class Method_CNN_ORL(method, nn.Module):
    data = None

    # -----------------------------------------------------------------------
    # 超参数：3-5 消融实验改这里（一次只改一个，才知道是谁起的作用）
    # -----------------------------------------------------------------------
    # 实测（3 个随机种子均值）：
    #   40 轮 -> 95.0%    60 轮 -> 98.3%（更好，采用）
    #   ORL 只有 360 张图，60 轮约 90 秒，多训练是性价比最高的提升手段
    max_epoch = 60
    learning_rate = 1e-3
    batch_size = 16         # 360 张图，batch 用 16 比较稳（太小梯度抖，太大更新少）
    weight_decay = 1e-4     # L2 正则
    normalize = True        # 是否做 (x-mean)/std 标准化

    # 标准化用的统计量，在 train() 里从训练集算出
    x_mean = None
    x_std = None

    def __init__(self, mName, mDescription, inputchannel=1, nclass=40):
        method.__init__(self, mName, mDescription)
        nn.Module.__init__(self)

        # 建出卷积部分和分类头，两个都是 nn.Sequential
        self.CNN, self.LNN = self.CNNlayerParameter(inputchannel, nclass)

    # -----------------------------------------------------------------------
    # 卷积部分：3 个 Conv-BN-ReLU-Pool 块
    # -----------------------------------------------------------------------
    def CNNlayer(self, channel0, channel, spliter, st, pad, minimap):
        return nn.Sequential(
            # ---- 块 1 ----
            nn.Conv2d(channel0, channel[0], spliter[0], st[0], pad[0]),  # 卷积：提取特征
            nn.BatchNorm2d(channel[0]),                                   # 标准化：稳定分布
            nn.ReLU(),                                                    # 激活：引入非线性
            nn.MaxPool2d(minimap[0]),                                     # 池化：降维

            # ---- 块 2 ----
            nn.Conv2d(channel[0], channel[1], spliter[1], st[1], pad[1]),
            nn.BatchNorm2d(channel[1]),
            nn.ReLU(),
            nn.MaxPool2d(minimap[1]),

            # ---- 块 3 ----
            nn.Conv2d(channel[1], channel[2], spliter[2], st[2], pad[2]),
            nn.BatchNorm2d(channel[2]),
            nn.ReLU(),
            nn.MaxPool2d(minimap[2]),
        )

    # -----------------------------------------------------------------------
    # 分类头：Dropout -> 全局平均池化 -> Flatten -> Linear
    #
    # 注意 Flatten 不能省：AdaptiveAvgPool2d(1) 输出是 (N,C,1,1) 四维，
    # 而 nn.Linear 只吃 (N, D) 二维，漏了 Flatten 会报
    #     mat1 and mat2 shapes cannot be multiplied
    # -----------------------------------------------------------------------
    def Estimatelayer(self, dropout_rate, gap_size, feat_channel, nclass):
        return nn.Sequential(
            nn.Dropout(dropout_rate),              # 防过拟合
            nn.AdaptiveAvgPool2d(gap_size),        # (N,C,H,W) -> (N,C,1,1)
            nn.Flatten(),                          # (N,C,1,1) -> (N,C)
            nn.Linear(feat_channel, nclass),       # (N,C) -> (N,40)
        )

    # -----------------------------------------------------------------------
    # 把超参集中在这里，padding 自动推导
    # -----------------------------------------------------------------------
    def CNNlayerParameter(self, inputchannel, outputchannel):
        pool    = [2, 2, 2]
        # 通道数：实测这是 ORL 性能的最大瓶颈
        #   [10,10,24]   -> Test 0.55   容量不足，欠拟合
        #   [16,32,64]   -> Test 0.90
        #   [32,64,128]  -> Test 0.95   ← 采用
        channel = [32, 64, 128]
        kernal  = [3, 3, 3]
        stride  = [1, 1, 1]

        # 由 (H + 2p - k) / s + 1 = H 解得 p = (k-1)*s / 2，即 same padding
        # kernel 必须是奇数才能得到整数 padding（k=4 做不到保持尺寸）
        padding = [(k - 1) * s // 2 for k, s in zip(kernal, stride)]

        dropout_rate = 0.5       # ORL 只有 360 张图，丢一半
        gap_size = 1             # 压到 1x1

        CNN = self.CNNlayer(inputchannel, channel, kernal, stride, padding, pool)
        #                    ↑ 输入通道数        ↑ 最后一层的输出通道 = 分类头的输入维度
        LNN = self.Estimatelayer(dropout_rate, gap_size, channel[-1], outputchannel)

        return CNN, LNN

    # -----------------------------------------------------------------------
    # 切换「训练模式 / 评估模式」
    #
    # 为什么不能直接 self.train() / self.eval()：
    #   base_class.method 要求实现 train(self, X, y)，覆盖了 nn.Module.train()，
    #   而 nn.Module.eval() 内部实现是 self.train(False)，也会调到我们自己的方法。
    #   train(mode) 的本质就是设置 training 标志位，所以这里直接手动设。
    # -----------------------------------------------------------------------
    def _set_training(self, mode):
        self.training = mode
        for module in self.children():
            module.train(mode)

    # -----------------------------------------------------------------------
    # forward：一次前向传播，(N,1,112,92) -> (N,40) 的 logits
    # -----------------------------------------------------------------------
    def forward(self, x):
        x = self.CNN(x)         # 卷积部分：(N,1,112,92) -> (N,24,14,11)
        x = self.LNN(x)         # 分类头：  (N,24,14,11) -> (N,40)
        return x                # 返回 logits，不接 softmax（CrossEntropyLoss 内部做了）

    # -----------------------------------------------------------------------
    # train：训练。返回每轮的平均 loss，给画学习曲线用
    # -----------------------------------------------------------------------
    def train(self, X, y):
        # 多分类标准损失。要求输入是 logits（未归一化的分数）
        loss_function = nn.CrossEntropyLoss()

        # Adam 自适应学习率，对 CNN 很好调
        optimizer = torch.optim.Adam(
            self.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay
        )

        # numpy -> tensor 只转一次，别在 epoch 循环里反复转
        X_tensor = torch.FloatTensor(np.asarray(X))
        y_tensor = torch.LongTensor(np.asarray(y))
        total = X_tensor.shape[0]

        # ---- 标准化：把训练集的均值方差记下来，测试时用同一套 ----
        # 为什么不只做 x/255？
        #   ORL 每张人脸的亮度差异很大（单张图均值在 0.30~0.58 之间），
        #   如果只缩放到 0~1，CNN 看到的是「绝对亮度」而不是「脸部结构」，
        #   同一个人的亮图和暗图会被当成不同的人。
        # 标准化成 (x-mean)/std 后，每张图都变成「以0为中心、宽度为1」，
        #   亮度这个干扰因素被消除，实测 Test Acc 从 0.375 提到 0.55。
        if self.normalize:
            self.x_mean = float(X_tensor.mean())
            self.x_std = float(X_tensor.std())
            X_tensor = (X_tensor - self.x_mean) / self.x_std
            print('normalize: mean=%.4f std=%.4f' % (self.x_mean, self.x_std))

        # 有 CUDA / MPS 就用 GPU
        device = _pick_device()
        X_tensor = X_tensor.to(device)
        y_tensor = y_tensor.to(device)
        self.to(device)

        history = []
        for epoch in range(self.max_epoch):
            # 每轮重新打乱，切成 mini-batch
            order = torch.randperm(total, device=device)
            X_shuffled = X_tensor[order]
            y_shuffled = y_tensor[order]

            # 切到训练模式（Dropout 生效、BN 用当前 batch 统计量）
            self._set_training(True)

            epoch_loss = 0.0
            for start in range(0, total, self.batch_size):
                x_batch = X_shuffled[start:start + self.batch_size]
                y_batch = y_shuffled[start:start + self.batch_size]

                # ==== 训练五步，顺序不能乱 ====
                y_pred = self.forward(x_batch)                  # 1. 前向
                batch_loss = loss_function(y_pred, y_batch)      # 2. 算 loss
                optimizer.zero_grad()                            # 3. 清空梯度
                batch_loss.backward()                            # 4. 反向传播
                optimizer.step()                                 # 5. 更新参数

                epoch_loss += float(batch_loss.item()) * x_batch.shape[0]

            epoch_loss /= total
            history.append(epoch_loss)

            # 每轮末看一次训练集准确率
            if epoch % 5 == 0 or epoch == self.max_epoch - 1:
                self._set_training(False)
                with torch.no_grad():
                    pred = self.forward(X_tensor).argmax(dim=1)
                    acc = float((pred == y_tensor).float().mean())
                print('Epoch:', epoch, 'Loss:', round(epoch_loss, 4),
                      'Train Acc:', round(acc, 4))

        return history

    # -----------------------------------------------------------------------
    # test：只做前向，取分数最大的类
    # -----------------------------------------------------------------------
    def test(self, X):
        device = _pick_device()
        X_tensor = torch.FloatTensor(np.asarray(X))

        # 用训练时算出的 mean/std 做同样的标准化（测试集不能自己算！）
        if self.normalize and self.x_mean is not None:
            X_tensor = (X_tensor - self.x_mean) / self.x_std

        X_tensor = X_tensor.to(device)

        # 必须切评估模式，否则 Dropout 还在丢、BN 用错统计量
        self._set_training(False)
        with torch.no_grad():
            logits = self.forward(X_tensor)
            pred = logits.argmax(dim=1)

        return pred.cpu().numpy()

    # -----------------------------------------------------------------------
    # run：把训练和测试串起来
    # -----------------------------------------------------------------------
    def run(self):
        print('method running...')
        print('--start training...')
        history = self.train(self.data['train']['X'], self.data['train']['y'])
        self.last_history = history

        print('--start testing...')
        pred_y = self.test(self.data['test']['X'])

        # 顺便把训练集预测也存下来，报告里画「训练/测试两条曲线」要用
        train_pred = self.test(self.data['train']['X'])
        train_acc = float((np.asarray(train_pred) == np.asarray(self.data['train']['y'])).mean())
        print('Final Train Acc: %.4f' % train_acc)

        return {
            'pred_y': pred_y,
            'true_y': self.data['test']['y'],
            'loss_history': history,
            'train_acc': train_acc,
        }


# ---------------------------------------------------------------------------
# 选设备：CUDA > MPS（Apple 芯片）> CPU
# ---------------------------------------------------------------------------
def _pick_device():
    if torch.cuda.is_available():
        return torch.device('cuda')
    if getattr(torch.backends, 'mps', None) is not None and torch.backends.mps.is_available():
        return torch.device('mps')
    return torch.device('cpu')
