"""
Stage 3 的 Setting：直接用老师切好的 train / test，不做交叉验证。

================================================================================
和模板的 Setting_Train_Test_Split.py 差别在哪
================================================================================
模板的 Setting 干的是这些事：
    loaded_data = self.dataset.load()                     # 读一份数据
    X_train, X_test, ... = train_test_split(...)          # 自己切 67/33
    self.method.data = {'train': ..., 'test': ...}
    learned_result = self.method.run()

Stage 3 的数据**老师已经切好了**（pickle 里 train 和 test 分开装），
所以把 train_test_split 那一行删掉，改成让 dataset 直接把两套都返回。

因为 Dataset_Loader.load() 返回的结构刚好就是
    {'train': {'X':..., 'y':...}, 'test': {'X':..., 'y':...}}
所以这里只需要一行 self.method.data = self.dataset.load()，其它全和模板一样。

这个文件几乎是原封不动的「五件套流水线」：
    dataset 装载 -> method 训练测试 -> result 存盘 -> evaluate 打分
"""

from local_code.base_class.setting import setting


class Setting_Train_Test_Split(setting):

    def load_run_save_evaluate(self):
        # ---- 1. 读数据（train/test 已经分好了，不用再切）----
        loaded_data = self.dataset.load()

        # ---- 2. 把数据交给 method，跑训练 + 测试 ----
        # loaded_data 的结构 {'train': {...}, 'test': {...}} 正好是 method 要的
        self.method.data = loaded_data
        learned_result = self.method.run()

        # ---- 3. 把预测结果存盘（pickle）----
        self.result.data = learned_result
        self.result.fold_count = None       # 没有 fold，存 None（文件名后缀会是 _None）
        self.result.save()

        # ---- 4. 算指标 ----
        self.evaluate.data = learned_result
        score = self.evaluate.evaluate()

        # 返回值固定是 (分数, 标准差) 两个，和模板一致
        return score, None
