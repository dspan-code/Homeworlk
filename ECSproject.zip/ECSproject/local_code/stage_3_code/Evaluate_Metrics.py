"""
Stage 3 的评估：Accuracy + Precision / Recall / F1（多分类版本）。

这个文件基本是从 Stage 2 原样拷过来的，因为评估指标和任务无关 ——
Stage 3 也是多分类（MNIST 10 类 / ORL 40 类 / CIFAR 10 类）。

================================================================================
为什么必须带 average='weighted'
================================================================================
多分类的 P/R/F1 不能像二分类那样直接算，sklearn 要求你指定一个「汇总方式」：
  · 'macro'    ：每个类别各算一个 P/R/F1，然后**直接平均**。
                 少数类的权重和多数类一样，所以对类别不平衡很敏感。
  · 'weighted' ：每个类别各算一个，然后**按该类的样本数加权平均**。
                 样本多的类影响更大，更接近整体准确率的直观感受。
  · 'micro'    ：把所有类的 TP/FP/FN 加起来再算。多分类 + 单标签时，
                 它其实就等于 accuracy，所以和三分类一起时报出来会重复。
本文件用 'weighted'，MNIST 的 10 个类别基本均衡，三种方式结果会很接近；
ORL 是每人恰好 1 张测试图，也很均衡，用哪种都行。
"""

from local_code.base_class.evaluate import evaluate
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report,
)


class Evaluate_Metrics(evaluate):
    data = None

    def evaluate(self):
        print('evaluating performance...')
        y_true = self.data['true_y']
        y_pred = self.data['pred_y']

        result = {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, average='weighted', zero_division=0),
            'recall': recall_score(y_true, y_pred, average='weighted', zero_division=0),
            'f1': f1_score(y_true, y_pred, average='weighted', zero_division=0),
        }

        # classification_report 会打印每个类别的 P/R/F1 和支持样本数，
        # 特别适合放进报告里分析「哪几类容易混」
        # （MNIST 通常是 4/9、3/8、5/6 这些长得像的数字混得最多）
        print(classification_report(y_true, y_pred, zero_division=0))
        print('Accuracy: %.4f  Precision: %.4f  Recall: %.4f  F1: %.4f' % (
            result['accuracy'], result['precision'], result['recall'], result['f1'],
        ))
        return result
