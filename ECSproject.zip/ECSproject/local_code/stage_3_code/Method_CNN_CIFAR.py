from local_code.base_class.method import method
import numpy as np
import torch
from torch import nn


def _init_weights(module):
    if isinstance(module, nn.Conv2d) or isinstance(module, nn.Linear):
        nn.init.kaiming_normal_(module.weight, nonlinearity='relu')
        if module.bias is not None:
            nn.init.zeros_(module.bias)


class Method_CNN_MNIST(method, nn.Module):
    data = None

    # ---- 超参数：3-5 消融实验改这里 ----
    max_epoch = 40
    learning_rate = 1e-3
    batch_size = 16
    weight_decay = 1e-4
    normalize = True
    x_mean = None
    x_std = None

    def __init__(self, mName, mDescription, inputchannel=3, nclass=10):
        # ---- Bug 1 修复：__init__ 必须有内容 ----
        method.__init__(self, mName, mDescription)
        nn.Module.__init__(self)

        # 用一个 Sequential 装下卷积部分 + 分类头
        self.net = self.CNNlayerParameter(inputchannel, nclass)
        # ---- Bug 7 修复：真正调用权重初始化 ----
        self.net.apply(_init_weights)

    # -----------------------------------------------------------------------
    # 卷积部分：3 个 (Conv-BN-ReLU-Pool-Dropout) 块
    # -----------------------------------------------------------------------
    def CNNlayer(self, channel0, channel, spliter, st, pad, minimap, memorylossing):
        return nn.Sequential(
            nn.Conv2d(channel0, channel[0], spliter[0], st[0], pad[0]),
            nn.BatchNorm2d(channel[0]),
            nn.ReLU(),
            nn.MaxPool2d(minimap[0]),
            nn.Dropout(memorylossing[0]),

            nn.Conv2d(channel[0], channel[1], spliter[1], st[1], pad[1]),
            nn.BatchNorm2d(channel[1]),
            nn.ReLU(),
            nn.MaxPool2d(minimap[1]),
            nn.Dropout(memorylossing[1]),

            nn.Conv2d(channel[1], channel[2], spliter[2], st[2], pad[2]),
            nn.BatchNorm2d(channel[2]),
            nn.ReLU(),
            nn.MaxPool2d(minimap[2]),
            nn.Dropout(memorylossing[2]),
        )

    # -----------------------------------------------------------------------
    # 分类头
    # -----------------------------------------------------------------------
    def Estimatelayer(self, memorylossing, finalchannelsize, channelo1, channelfinal):
        return nn.Sequential(
            nn.AdaptiveAvgPool2d(finalchannelsize),
            nn.Flatten(),
            nn.Linear(channelo1[0], channelfinal),
            #nn.ReLU(),
            #nn.Dropout(memorylossing),
            #nn.Linear(channelo1[1], channelfinal),
        )

    # -----------------------------------------------------------------------
    # 参数装配
    # -----------------------------------------------------------------------
    def CNNlayerParameter(self, inputchannel, outputchannel):
        pool    = [2, 2, 2]
        channel = [32, 64,128]
        kernal  = [3, 5, 5]
        stride  = [3, 3, 3]
        padding = [(k - 1) * s // 2 for k, s in zip(kernal, stride)]

        kernel_dropout = [0., 0, 0]      # 卷积块之间的 dropout（0.01 太小了）
        CNN = self.CNNlayer(inputchannel, channel, kernal, stride, padding, pool, kernel_dropout)

        head_dropout = 0                     # 分类头 dropout
        fnpool = 1
        channelo1 = [channel[-1], 70]

        # ---- Bug 4 修复：按正确顺序传 4 个参数 ----
        LNN = self.Estimatelayer(head_dropout, fnpool, channelo1, outputchannel)

        return nn.Sequential(CNN, LNN)

    # -----------------------------------------------------------------------
    # 模式切换（替代 self.train()/self.eval()）
    # ---- Bug 2 修复：补上这个方法 ----
    # ---- Bug 5 说明：用 nn.Module.train(self, mode) 设置，不要手写 self.training ----
    # -----------------------------------------------------------------------
    def _set_training(self, mode):
        nn.Module.train(self, mode)      # 内部会设置 self.training 并递归子模块

    def forward(self, x):
        return self.net(x)

    # -----------------------------------------------------------------------
    # 标准化
    # -----------------------------------------------------------------------
    def _to_tensor(self, X, fit=False):
        X_t = torch.FloatTensor(np.asarray(X))
        if self.normalize:
            if fit:                                   # 训练集：算 mean/std
                self.x_mean = float(X_t.mean())
                self.x_std = float(X_t.std())
                print('normalize: mean=%.4f std=%.4f' % (self.x_mean, self.x_std))
            if self.x_mean is not None:               # 测试集：用同一套
                X_t = (X_t - self.x_mean) / self.x_std
        return X_t

    # -----------------------------------------------------------------------
    # 训练
    # -----------------------------------------------------------------------
    def train_model(self, X, y):
        optimizer = torch.optim.Adam(self.parameters(), lr=self.learning_rate,
                                     weight_decay=self.weight_decay)
        loss = nn.CrossEntropyLoss()

        device = _pick_device()
        self.to(device)
        X_t = self._to_tensor(X, fit=True).to(device)
        y_t = torch.LongTensor(np.asarray(y)).to(device)

        history = []
        for epoch in range(self.max_epoch):
            self._set_training(True)          # 用 _set_training，不要手写 self.training = True

            order = torch.randperm(len(X_t), device=device)
            Xs, ys = X_t[order], y_t[order]

            epoch_loss = 0.0
            for start in range(0, len(Xs), self.batch_size):
                xb = Xs[start:start + self.batch_size]
                yb = ys[start:start + self.batch_size]

                y_pred = self.forward(xb)
                batch_loss = loss(y_pred, yb)
                optimizer.zero_grad()
                batch_loss.backward()
                optimizer.step()

                epoch_loss += float(batch_loss.item()) * xb.shape[0]

            epoch_loss /= len(Xs)
            history.append(epoch_loss)

            # 每轮末切评估模式看训练准确率
            self._set_training(False)
            with torch.no_grad():
                acc = float((self.forward(X_t).argmax(1) == y_t).float().mean())
            print('Epoch:', epoch, 'Loss:', round(epoch_loss, 4), 'Train Acc:', round(acc, 4))

        return history

    # -----------------------------------------------------------------------
    # 测试
    # ---- Bug 3 修复：语法 ----
    # ---- Bug 6 修复：返回类别标签，不是 logits ----
    # -----------------------------------------------------------------------
    def test_model(self, X):
        device = _pick_device()
        self.to(device)
        X_t = self._to_tensor(X).to(device)

        self._set_training(False)
        with torch.no_grad():
            y_pred = self.forward(X_t)

        return y_pred.argmax(dim=1).cpu().numpy()

    # -----------------------------------------------------------------------
    # 主流程
    # -----------------------------------------------------------------------
    def run(self):
        print('--training..')
        history = self.train_model(self.data['train']['X'], self.data['train']['y'])
        self.last_history = history

        print('--testing...')
        pred_y = self.test_model(self.data['test']['X'])

        return {'pred_y': pred_y, 'true_y': self.data['test']['y'], 'loss_history': history}


def _pick_device():
    if torch.cuda.is_available():
        return torch.device('cuda')
    if getattr(torch.backends, 'mps', None) is not None and torch.backends.mps.is_available():
        return torch.device('mps')
    return torch.device('cpu')
