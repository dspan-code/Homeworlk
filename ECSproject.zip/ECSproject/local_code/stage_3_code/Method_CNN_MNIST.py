"""
Stage 3 的 CNN 模型（MNIST 手写数字识别）。

这是整个 Stage 3 的核心文件。它和 Stage 2 的 Method_MLP.py 是同一个套路
（继承 method + nn.Module，实现 forward / train / test / run），
唯一的区别在 forward() 里：多了卷积层。

================================================================================
【第 1 步】先把「一张 28x28 的图在 CNN 里一路走下来的形状变化」想清楚
================================================================================

PyTorch 的卷积层 Conv2d 只接受 4 维输入：(N, C, H, W)
    N = 一个 batch 里有几张图
    C = 通道数（灰度图 1，彩色图 3）
    H, W = 高和宽

MNIST 是 28x28 灰度图，所以进网络时是 (N, 1, 28, 28)。
Dataset_Loader 已经把形状整理好了，所以这里不用再 reshape。

本模型的形状变化表（把这张表背下来，CNN 就不会写错）：

    层                      输出形状                参数量说明
    -------------------------------------------------------------------
    输入                    (N, 1, 28, 28)
    Conv2d(1, 8, k=3,p=1)   (N, 8, 28, 28)          卷积 keep size（padding=1）
    ReLU                    (N, 8, 28, 28)
    MaxPool2d(2)            (N, 8, 14, 14)          池化把 HW 减半
    Conv2d(8, 16, k=3,p=1)  (N, 16, 14, 14)
    ReLU                    (N, 16, 14, 14)
    MaxPool2d(2)            (N, 16, 7, 7)           再减半
    flatten                 (N, 16*7*7 = 784)       摊平成一维向量
    Linear(784, 128)        (N, 128)
    ReLU                    (N, 128)
    Linear(128, 10)         (N, 10)                 ← 输出层，10 个类别

卷积输出边长的公式（3-5 消融实验会反复用到）：
    H_out = (H_in + 2*padding - kernel_size) / stride + 1

把 k=3, p=1, s=1 代进去：(28 + 2 - 3)/1 + 1 = 28，尺寸不变，所以叫 "same" 卷积。
池化 k=2, s=2：(28 - 2)/2 + 1 = 14，正好减半。

================================================================================
【第 2 步】一个必须记住的坑：最后一层不要接 softmax
================================================================================
nn.CrossEntropyLoss 内部已经做了 log_softmax + NLLLoss。
如果最后一层再接一个 Softmax，等于归一化了两次，
梯度会变得非常小，模型基本学不动（Stage 2 的模板就有这个问题，注释里写了）。

所以：forward() 的返回值是 **logits**（未归一化的分数），不是概率。

================================================================================
【第 3 步】为什么训练时要 shuffle + mini-batch
================================================================================
模板原版是「整个训练集一次性喂进去」（full batch）。6 万张图一次性前向，
内存吃得凶，而且一轮只更新一次参数，收敛慢。
改成 mini-batch（每批 128 张，每轮打乱顺序）后：
  · 一轮更新 60000/128 ≈ 469 次，收敛快得多
  · 打乱顺序防止模型记住「喂数据的顺序」

================================================================================
【第 4 步】你为了 ORL / CIFAR 要改什么
================================================================================
· Method_CNN_ORL.py：
    - 输入 (N, 1, 112, 92)，H 和 W 不等，flatten 前是 16*28*23（自己按公式算清楚）
    - 输出 40 类，不是 10 类
    - 数据只有 360 张，很容易过拟合 -> 加 Dropout、减小模型、降低学习率
· Method_CNN_CIFAR.py：
    - 输入 (N, 3, 32, 32)，第一层卷积 in_channels=3
    - 输出 10 类
    - 3 万/5 万张彩色图，模型要更深一点才学得好

改法：把下面这个类整个复制成新文件，改 __init__ 里的层定义和 forward 里的形状即可。
"""

from local_code.base_class.method import method
import numpy as np
import torch
from torch import nn


# ---------------------------------------------------------------------------
# 小工具：把权重初始化做一下。
# 卷积层默认初始化也行，但这个对 CNN 更稳，配上 ReLU 收敛更快。
# ---------------------------------------------------------------------------
def _init_weights(module):
    if isinstance(module, nn.Conv2d) or isinstance(module, nn.Linear):
        # kaiming 初始化是专门为 ReLU 设计的：让每一层输出的方差保持一致，
        # 避免层数一深信号就衰减到 0（梯度消失）。
        nn.init.kaiming_normal_(module.weight, nonlinearity='relu')
        if module.bias is not None:
            nn.init.zeros_(module.bias)


class Method_CNN_MNIST(method, nn.Module):
    data = None

    # -----------------------------------------------------------------------
    # 超参数：3-5 消融实验就改这里（一次只改一个，才知道是谁起的作用）
    # -----------------------------------------------------------------------
    max_epoch = 10          # 训练轮数。MNIST 上 10 轮就能到 99% 左右
    learning_rate = 1e-3    # 学习率
    batch_size = 128        # 每批多少张图
    weight_decay = 1e-4     # L2 正则，轻微压制过拟合

    def __init__(self, mName, mDescription):
        method.__init__(self, mName, mDescription)
        nn.Module.__init__(self)

        # ---- 卷积部分（特征提取）--------------------------------------
        # Conv2d(in_channels, out_channels, kernel_size, stride, padding)
        #   1 -> 8：输入灰度图 1 通道，输出 8 个特征图（8 个不同的「滤波器」，
        #           有的学边缘，有的学拐角）
        #   k=3  ：3x3 的卷积核
        #   p=1  ：四周补一圈 0，让输出尺寸和输入一样（28->28），叫 same padding
        self.conv_1 = nn.Conv2d(in_channels=1, out_channels=8,
                                kernel_size=3, stride=1, padding=1)
        self.relu_1 = nn.ReLU()
        # MaxPool2d(2)：每 2x2 的窗口取最大值，把 28x28 压成 14x14。
        # 作用：减少计算量 + 让模型对小范围平移不敏感
        self.pool_1 = nn.MaxPool2d(kernel_size=2)

        self.conv_2 = nn.Conv2d(in_channels=8, out_channels=16,
                                kernel_size=3, stride=1, padding=1)
        self.relu_2 = nn.ReLU()
        self.pool_2 = nn.MaxPool2d(kernel_size=2)   # 14x14 -> 7x7

        # BatchNorm2d 是一种「每层归一化」，让训练更稳更快。
        # 这里放一个在卷积后面，可以当作 3-5 实验里「加不加 BN」的对比项。
        self.bn_1 = nn.BatchNorm2d(16)

        # ---- 全连接部分（分类）----------------------------------------
        # 16 个通道 x 7 x 7 = 784 个特征，摊平后接全连接
        # 注意：这个 784 是「图像形状决定的」，不是 MNIST 那个 28*28=784 的巧合。
        #       你做 ORL 时这个数会变成 16 * 28 * 23 之类的，一定要自己算。
        self.fc_1 = nn.Linear(16 * 7 * 7, 128)
        self.relu_3 = nn.ReLU()
        # Dropout：训练时随机丢掉 30% 的神经元，防止过拟合。
        # 测试时 nn.Module 会自动关掉它（eval 模式下）。
        self.dropout = nn.Dropout(0.3)
        # 输出层：128 -> 10 类。**不接 softmax**（见文件开头第 2 步）
        self.fc_2 = nn.Linear(128, 10)

        # 初始化一遍权重
        self.apply(_init_weights)

    # -----------------------------------------------------------------------
    # 切换「训练模式 / 评估模式」
    #
    # ⚠️ 这是继承模板时最容易踩的坑，一定要看：
    #   base_class.method 要求我们实现 train(self, X, y)，
    #   而 nn.Module 自己也有一个 train(self, mode=True) 用来切换模式。
    #   我们的定义把 nn.Module 那个覆盖掉了，于是：
    #       self.train()      -> 调到自己，报 "missing 2 required positional arguments"
    #       self.eval()       -> 内部实现是 self.train(False)，也会调到自己，同样报错
    #   所以两种「一行写法」都用不了，必须直接改底层的 training 标志位。
    #   （train(mode) 的本质就是把 self.training 和所有子模块的 training 设成 mode）
    # -----------------------------------------------------------------------
    def _set_training(self, mode):
        self.training = mode
        for module in self.children():
            module.train(mode)


    # -----------------------------------------------------------------------
    # forward：一次前向传播，把 (N,1,28,28) 变成 (N,10) 的 logits
    # -----------------------------------------------------------------------
    def forward(self, x):
        '''Forward propagation'''
        # ---- 卷积块 1：(N,1,28,28) -> (N,8,14,14)
        x = self.conv_1(x)          # (N, 8, 28, 28)
        x = self.relu_1(x)          # ReLU 不改变形状
        x = self.pool_1(x)          # (N, 8, 14, 14)

        # ---- 卷积块 2：(N,8,14,14) -> (N,16,7,7)
        x = self.conv_2(x)          # (N, 16, 14, 14)
        x = self.bn_1(x)            # BatchNorm 也不改变形状
        x = self.relu_2(x)
        x = self.pool_2(x)          # (N, 16, 7, 7)

        # ---- 摊平：(N,16,7,7) -> (N,784)
        # x.size(0) 是 N，-1 让 PyTorch 自动算出 16*7*7
        x = x.view(x.size(0), -1)

        # ---- 全连接分类：(N,784) -> (N,10)
        x = self.fc_1(x)
        x = self.relu_3(x)
        x = self.dropout(x)
        x = self.fc_2(x)            # 输出 logits，不接 softmax

        return x

    # -----------------------------------------------------------------------
    # train：一次梯度下降优化。返回每轮的平均 loss（给画学习曲线用）
    # -----------------------------------------------------------------------
    def train(self, X, y):
        # ---- 选损失函数 ----
        # 多分类标准选择。它内部 = log_softmax + NLLLoss，所以要求输入是 logits。
        loss_function = nn.CrossEntropyLoss()

        # ---- 选优化器 ----
        # Adam 会自适应调每个参数的学习率，比 SGD 好调，1e-3 基本就够。
        # 3-5 实验里可以换成 torch.optim.SGD(..., momentum=0.9) 做对比。
        optimizer = torch.optim.Adam(
            self.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay
        )

        # ---- numpy -> tensor 只做一次 ----
        # 千万别在 epoch 循环里反复转，6 万张图每次转一遍非常慢。
        X_tensor = torch.FloatTensor(np.asarray(X))
        y_tensor = torch.LongTensor(np.asarray(y))
        total = X_tensor.shape[0]

        # 有 GPU/MPS 就搬过去
        device = _pick_device()
        X_tensor = X_tensor.to(device)
        y_tensor = y_tensor.to(device)
        self.to(device)

        history = []
        for epoch in range(self.max_epoch):
            # ---- 每轮打乱一次，然后切成 mini-batch ----
            order = torch.randperm(total, device=device)
            X_shuffled = X_tensor[order]
            y_shuffled = y_tensor[order]

            # 关键：告诉 PyTorch「现在在训练」。
            # 这会让 Dropout 生效、BatchNorm 用当前 batch 的均值方差。
            # （为什么调的是 _set_training 而不是 self.train()，见文件末尾的说明）
            self._set_training(True)

            epoch_loss = 0.0
            for start in range(0, total, self.batch_size):
                x_batch = X_shuffled[start:start + self.batch_size]
                y_batch = y_shuffled[start:start + self.batch_size]

                # ==== 训练五步，顺序不能乱 ====
                y_pred = self.forward(x_batch)                 # 1. 前向
                batch_loss = loss_function(y_pred, y_batch)     # 2. 算 loss
                optimizer.zero_grad()                           # 3. 清空上一轮梯度
                batch_loss.backward()                           # 4. 反向传播
                optimizer.step()                                # 5. 更新参数

                # 累加本批 loss（乘批大小，最后除以总数才是「每张图的平均 loss」）
                epoch_loss += float(batch_loss.item()) * x_batch.shape[0]

            epoch_loss /= total
            history.append(epoch_loss)

            # ---- 每轮结束看一眼训练集准确率 ----
            if epoch % 2 == 0 or epoch == self.max_epoch - 1:
                with torch.no_grad():
                    # 切到评估模式：关掉 Dropout、BatchNorm 用滑动平均
                    self._set_training(False)
                    pred = self.forward(X_tensor).argmax(dim=1)
                    acc = float((pred == y_tensor).float().mean())
                print('Epoch:', epoch, 'Loss:', round(epoch_loss, 4),
                      'Train Acc:', round(acc, 4))

        return history

    # -----------------------------------------------------------------------
    # test：只做前向，取分数最大的类作为预测
    # -----------------------------------------------------------------------
    def test(self, X):
        device = _pick_device()
        X_tensor = torch.FloatTensor(np.asarray(X)).to(device)

        # 切到评估模式关掉 Dropout，否则同一张图测两次结果可能不一样
        self._set_training(False)
        with torch.no_grad():                    # 不用建计算图，省内存
            logits = self.forward(X_tensor)
            pred = logits.argmax(dim=1)

        return pred.cpu().numpy()

    # -----------------------------------------------------------------------
    # run：把 train 和 test 串起来，返回结果给 Setting
    # -----------------------------------------------------------------------
    def run(self):
        print('method running...')
        print('--start training...')
        history = self.train(self.data['train']['X'], self.data['train']['y'])
        self.last_history = history          # 留给脚本存曲线

        print('--start testing...')
        pred_y = self.test(self.data['test']['X'])
        return {
            'pred_y': pred_y,
            'true_y': self.data['test']['y'],
            'loss_history': history,
        }


# ---------------------------------------------------------------------------
# 选设备：有 MPS（Apple 芯片 GPU）就用 MPS，有 CUDA 就用 CUDA，否则 CPU
# 这是 3-7 那个 Optional 要求的「跑在 GPU 上」
# ---------------------------------------------------------------------------
def _pick_device():
    if torch.cuda.is_available():
        return torch.device('cuda')
    if getattr(torch.backends, 'mps', None) is not None and torch.backends.mps.is_available():
        return torch.device('mps')
    return torch.device('cpu')
