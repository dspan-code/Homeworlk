"""
通用学习曲线画图脚本 —— 三个数据集通用。

运行方式（在 script/stage_3_script/ 目录下执行）：
    cd script/stage_3_script

    # 画某一个
    PYTHONPATH=../.. python3 plot_curve.py CIFAR
    PYTHONPATH=../.. python3 plot_curve.py MNIST
    PYTHONPATH=../.. python3 plot_curve.py ORL

    # 或者一次画全部（缺数据的会自动跳过）
    PYTHONPATH=../.. python3 plot_curve.py all

输入：result/stage_3_result/CNN_<名字>_loss_history.txt   （每行 "epoch,loss"）
输出：result/stage_3_result/CNN_<名字>_loss_curve.png

只要你有 loss_history.txt，就能画。没有就先跑对应的训练脚本。
"""

import os
import sys

import matplotlib
matplotlib.use('Agg')          # 无显示环境也能存图
from matplotlib import pyplot as plt


RESULT_DIR = '../../result/stage_3_result'

# 每个数据集单独配色和标题，报告里一眼能区分
STYLE = {
    'MNIST': dict(color='#2f5597', title='MNIST CNN — Training Loss'),
    'ORL':   dict(color='#c00000', title='ORL CNN — Training Loss'),
    'CIFAR': dict(color='#548235', title='CIFAR-10 CNN — Training Loss'),
}


def load_history(name):
    """读 loss_history.txt，返回 (epochs, losses)。文件不存在返回 None。"""
    csv_path = os.path.join(RESULT_DIR, 'CNN_%s_loss_history.txt' % name)
    if not os.path.exists(csv_path):
        return None

    epochs, losses = [], []
    with open(csv_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            epoch, loss = line.split(',')
            epochs.append(int(epoch))
            losses.append(float(loss))
    return epochs, losses


def plot_one(name):
    data = load_history(name)
    if data is None:
        print('[跳过] %s: 找不到 CNN_%s_loss_history.txt' % (name, name))
        return False

    epochs, losses = data
    style = STYLE.get(name, dict(color='#2f5597', title='%s CNN — Training Loss' % name))

    plt.figure(figsize=(7, 4.5))
    plt.plot(epochs, losses, marker='o', markersize=3.5, linewidth=1.8,
             color=style['color'])
    plt.xlabel('Epoch')
    plt.ylabel('Training Loss (cross-entropy)')
    plt.title(style['title'])
    plt.grid(True, alpha=0.3)
    plt.tight_layout()

    png_path = os.path.join(RESULT_DIR, 'CNN_%s_loss_curve.png' % name)
    plt.savefig(png_path, dpi=150)
    plt.close()

    # 打印报告要用的数字
    print('[完成] %-6s  %s' % (name, png_path))
    print('        轮数 %d, loss %.4f -> %.4f (下降 %.1f%%)'
          % (len(losses), losses[0], losses[-1],
             (losses[0] - losses[-1]) / losses[0] * 100))
    return True


if __name__ == '__main__':
    target = sys.argv[1] if len(sys.argv) > 1 else 'all'

    if target == 'all':
        names = ['MNIST', 'ORL', 'CIFAR']
    else:
        names = [target.upper()]

    done = [n for n in names if plot_one(n)]
    print('\n共生成 %d 张图' % len(done))
