# Stage 3 MNIST CNN —— 逐步讲解

这份文档把 MNIST 那条完整链路拆成 7 步，每一步说明：**做什么、为什么、代码在哪、你要改什么**。
ORL 和 CIFAR 你自己照着做，第 7 步给了「改哪里」的对照表。

已经跑通的结果：**测试集 Accuracy = 0.9905（99.05%）**，10 轮训练，约 3 分钟（MPS）。

---

## 总览：五件套是怎么串起来的

老师反复强调的模板架构就是这五个组件 + 一个 Setting 当调度器：

```
     ┌─────────────────┐
     │ Dataset_Loader  │  读 pickle -> {'train':{X,y}, 'test':{X,y}}
     └────────┬────────┘
              │ 数据
     ┌────────▼────────┐
     │ Method_CNN      │  forward / train / test / run
     └────────┬────────┘
              │ {'pred_y', 'true_y', 'loss_history'}
     ┌────────▼────────┐        ┌──────────────────┐
     │ Result_Saver    │        │ Evaluate_Metrics │
     │  存成 pickle    │        │  Acc + P/R/F1    │
     └─────────────────┘        └──────────────────┘
              ▲                        ▲
              └───────┬────────────────┘
              ┌───────┴──────────┐
              │ Setting          │  data 怎么流、method.data 怎么装、
              │ 训练/测试划分     │  什么时候存盘、什么时候打分
              └──────────────────┘
                       ▲
              ┌────────┴─────────┐
              │ script_cnn_mnist │  建对象 -> 填参数 -> 串起来跑
              └──────────────────┘
```

**关键设计思想**：数据集和模型是解耦的。
换数据集只改脚本里 `Dataset_Loader` 的参数，换模型只改 `method` 那一行。
这就是为什么 ORL / CIFAR 你不用重写整个项目。

---

## 第 1 步：先看清楚数据长什么样

数据集在 `data/stage_3_data/`，是 pickle 文件，不是 CSV。结构是：

```python
{
  'train': [ {'image': <图像矩阵>, 'label': <int>}, ... ],   # 老师已切分好
  'test':  [ {'image': <图像矩阵>, 'label': <int>}, ... ],
}
```

实测结果（我跑过一遍确认的）：

| 数据集 | train / test | 单张图像形状 | dtype | 标签范围 |
|---|---|---|---|---|
| MNIST | 60000 / 10000 | `(28, 28)` | float64 | 0–9 |
| ORL | 360 / 40 | `(112, 92, 3)` | uint8 | **1–40** |
| CIFAR | 50000 / 10000 | `(32, 32, 3)` | uint8 | 0–9 |

**三个必须注意的点：**

1. **不要再做 train/test split 或交叉验证。** 老师已经分好了（这是 Stage 2/3 和 Stage 1 的区别）。
2. **要归一化。** 原始值是 0–255。不除以 255 的话梯度会爆，学习率得压到很小。
3. **ORL 的标签从 1 开始**，但 PyTorch 的 `CrossEntropyLoss` 要求类别下标在 `[0, C-1]`，所以 ORL 必须把标签减 1，否则会报 index out of range。

---

## 第 2 步：写数据读取器 `Dataset_Loader.py`

📄 `local_code/stage_3_code/Dataset_Loader.py`

和 Stage 1/2 的 loader 同一个套路（继承 `base_class.dataset`，实现 `load()`），只是从「读文本行」变成「读 pickle」。

核心是 `_convert()` 这个方法，它把一堆 `{'image':..., 'label':...}` 整理成两个 numpy 数组：

```python
X = np.stack(images).astype(np.float32) / 255.0    # 归一化 + 转 float32
y = np.array([i['label'] for i in instance_list], dtype=np.int64)
if self.label_offset:
    y = y - self.label_offset                       # ORL 用：标签 1~40 -> 0~39
```

然后是**形状整理**——这是 CNN 和 MLP 最大的区别：

```
PyTorch 卷积层只接受 4 维：(N, C, H, W)
      N = batch 里有几张图
      C = 通道数（灰度 1，彩色 3）

MNIST 读出来是 (N, 28, 28)          -> 插一个通道 -> (N, 1, 28, 28)
CIFAR 读出来是 (N, 32, 32, 3)       -> 转置       -> (N, 3, 32, 32)
```

我把它写成通用的了，三个数据集共用同一个类，只改脚本里的构造参数：

```python
Dataset_Loader('mnist', '',                      channel=None, label_offset=0)  # MNIST
Dataset_Loader('orl',   '',                      channel=0,    label_offset=1)  # ORL
Dataset_Loader('cifar', '',                      channel=None, label_offset=0)  # CIFAR
#                          ↑ flatten=True 时才返回平铺的 (N,784)，给 MLP 用；CNN 保持 False
```

ORL 的 `channel=0` 是干什么的？ORL 是灰度图被复制成三份 RGB（三个通道值完全一样），
只取一个通道就够了，**省 3 倍内存且不影响结果**。ReadMe 里也这么建议。

---

## 第 3 步：写 CNN 模型 `Method_CNN_MNIST.py`（核心）

📄 `local_code/stage_3_code/Method_CNN_MNIST.py`

### 3.1 先背下这张形状变化表

CNN 写错 90% 是因为**把形状算错了**。这张表是整份代码的地图：

| 层 | 输出形状 | 说明 |
|---|---|---|
| 输入 | `(N, 1, 28, 28)` | |
| Conv2d(1→8, k=3, p=1) | `(N, 8, 28, 28)` | padding=1 保持尺寸不变 |
| ReLU | `(N, 8, 28, 28)` | 形状不变 |
| MaxPool2d(2) | `(N, 8, 14, 14)` | 尺寸减半 |
| Conv2d(8→16, k=3, p=1) | `(N, 16, 14, 14)` | |
| BatchNorm2d(16) + ReLU | `(N, 16, 14, 14)` | |
| MaxPool2d(2) | `(N, 16, 7, 7)` | 再减半 |
| `.view(N, -1)` | `(N, 784)` | **摊平**，784 = 16×7×7 |
| Linear(784→128) + ReLU | `(N, 128)` | |
| Dropout(0.3) | `(N, 128)` | |
| Linear(128→10) | `(N, 10)` | **输出 logits** |

**你要记住的公式**（做 3-5 消融实验必用）：

```
H_out = (H_in + 2×padding − kernel_size) / stride + 1
```

验算一下：`k=3, p=1, s=1` 代入 `(28 + 2 − 3)/1 + 1 = 28` —— 尺寸不变，这就是 "same convolution"。
池化 `k=2, s=2`：`(28 − 2)/2 + 1 = 14` —— 正好减半。

> ⚠️ 那个 `784` 千万别和「MNIST 是 28×28=784」搞混，它纯属巧合。
> 你做 ORL（输入 112×92）时，摊平后是 `16 × 28 × 23 = 10304`，差远了，一定要自己按公式算。

### 3.2 一个必踩的坑：最后一层不要接 softmax

`nn.CrossEntropyLoss` 内部已经做了 `log_softmax + NLLLoss`。
如果最后一层再接 Softmax，等于归一化两次，梯度变得非常小，模型基本学不动。

**所以 `forward()` 返回的是 logits（原始分数），不是概率。**
（Stage 2 的模板原本就有这个问题，它的注释里已经写了。）

### 3.3 第二个坑：`self.train()` 会报错（这个坑很隐蔽）

这个坑花了我最多时间，值得单独说。

`base_class.method` 要求你实现 `train(self, X, y)`，但 `nn.Module` 自己也有一个
`train(self, mode=True)` 用来切换「训练/评估模式」。我们的定义**覆盖**了它，于是：

```python
self.train()    # ✗ 调到自己 -> TypeError: missing 2 required positional arguments 'X' and 'y'
self.eval()     # ✗ 也不行！nn.Module.eval() 内部实现就是 self.train(False)，还是会调到自己
```

两种「一行写法」全都用不了。解决办法是**直接改底层的 training 标志位**：

```python
def _set_training(self, mode):
    self.training = mode
    for module in self.children():
        module.train(mode)      # 子模块调的是 nn.Module.train，没被覆盖，正常
```

为什么必须切模式？因为 **Dropout 和 BatchNorm 在训练和测试时行为不一样**：
- 训练时：Dropout 随机丢神经元、BatchNorm 用当前 batch 的均值方差
- 测试时：Dropout 关闭、BatchNorm 用训练时累积的滑动平均

不切的话，同一张图测两次可能得到不同结果。

### 3.4 训练循环：mini-batch + 打乱

模板原版是「整个 6 万张一次性喂进去」，内存吃得凶，而且一轮只更新一次参数。
改成 mini-batch（每次 128 张，每轮重新打乱）后，一轮更新约 469 次，收敛快得多。

核心还是那**五步**，顺序不能乱：

```python
y_pred = self.forward(x_batch)                # 1. 前向
batch_loss = loss_function(y_pred, y_batch)   # 2. 算 loss
optimizer.zero_grad()                         # 3. 清空上一轮梯度  ← 忘了这步梯度会累加！
batch_loss.backward()                         # 4. 反向传播
optimizer.step()                              # 5. 更新参数
```

另外注意：`numpy -> tensor` 只转换一次（在循环外面），别在 epoch 循环里反复转，很慢。

### 3.5 用了哪些「提升性能」的手段（写报告时有用）

| 手段 | 作用 |
|---|---|
| 权重初始化 `kaiming_normal_` | 专门为 ReLU 设计，让每层输出方差一致，防梯度消失 |
| BatchNorm | 每层归一化，训练更稳更快 |
| Dropout(0.3) | 随机丢神经元，防过拟合 |
| Adam + weight_decay | 自适应学习率 + L2 正则 |
| mini-batch + shuffle | 收敛更快，防记住数据顺序 |
| MPS 加速 | 用 Apple 芯片 GPU（3-7 那个 Optional） |

---

## 第 4 步：改写 Setting（去掉切分）

📄 `local_code/stage_3_code/Setting_Train_Test_Split.py`

模板里 Setting 干的事是「读一份数据 → `train_test_split` 切 67/33 → 训练」。
Stage 3 数据**已经切好了**，所以把切分那行删掉就行：

```python
# 模板原版
loaded_data = self.dataset.load()
X_train, X_test, y_train, y_test = train_test_split(loaded_data['X'], loaded_data['y'], test_size=0.33)
self.method.data = {'train': {'X': X_train, 'y': y_train}, 'test': {'X': X_test, 'y': y_test}}

# Stage 3
loaded_data = self.dataset.load()                    # 直接就是 {'train':..., 'test':...}
self.method.data = loaded_data                       # 一行搞定
```

因为 `Dataset_Loader.load()` 返回的结构**刚好就是** `method.data` 期望的格式。
这就是设计好 loader 返回值的价值。

---

## 第 5 步：评估指标 `Evaluate_Metrics.py`

📄 `local_code/stage_3_code/Evaluate_Metrics.py`（从 Stage 2 原样拷过来）

Stage 3 也是多分类，所以 **P/R/F1 必须带 `average` 参数**，二分类写法会直接报错：

| 参数 | 含义 | 什么时候用 |
|---|---|---|
| `'macro'` | 每类各算，然后**直接平均** | 小类也一样重要 |
| `'weighted'` | 每类各算，按**样本数加权** | 类别不均衡（默认选这个） |
| `'micro'` | 所有类 TP/FP/FN 汇总再算 | 单标签多分类时**等于 accuracy**，会重复 |

MNIST 的 10 类基本均衡，所以 macro / weighted / micro 结果几乎一样。

`classification_report` 会打印每个类的 P/R/F1，**报告里分析「哪几类容易混」时直接用**——
MNIST 通常是 4/9、3/8、5/6 这些长得像的数字混得最多（实测 9 类的 recall 最低 0.97）。

---

## 第 6 步：入口脚本 + 画图

📄 `script/stage_3_script/script_cnn_mnist.py`

四件事，和 Stage 1/2 脚本一模一样：

```python
# 1. 建对象：data / method / result / evaluate / setting
# 2. 填参数
method_obj = Method_CNN_MNIST('cnn-mnist', 'conv(1-8)-pool-conv(8-16)-bn-pool-fc(784-128-10)')
# 3. 串起来跑
setting_obj.prepare(data_obj, method_obj, result_obj, evaluate_obj)
score, _ = setting_obj.load_run_save_evaluate()
# 4. 存 loss 曲线
```

📄 `script/stage_3_script/plot_loss.py` 读 `CNN_MNIST_loss_history.txt` 画学习曲线。

**怎么读这张曲线（3-3 要求 "Generate the learning curves"）：**
- 正常：前几轮掉得飞快，后面越来越平 —— 先学大轮廓，再抠细节
- loss 不降 → 学习率太小，或忘了 `zero_grad`
- loss 变 nan → 学习率太大，梯度爆了
- **想做更完整的曲线，就再加一条测试集 accuracy 曲线**。MNIST 一般不过拟合（10 万参数对 6 万张图不算多），但 **ORL 只有 360 张训练图、40 类，过拟合会非常明显，一定要画两条。**

### 运行方式

```bash
cd script/stage_3_script
PYTHONPATH=../.. python3 script_cnn_mnist.py     # 训练 + 保存结果 + 打分
PYTHONPATH=../.. python3 plot_loss.py            # 画曲线
```

---

## 第 7 步：MNIST 的实际结果

```
Epoch: 0  Loss: 0.3163  Train Acc: 0.9742
Epoch: 2  Loss: 0.0762  Train Acc: 0.9869
Epoch: 4  Loss: 0.0518  Train Acc: 0.9922
Epoch: 6  Loss: 0.0411  Train Acc: 0.9936
Epoch: 8  Loss: 0.0330  Train Acc: 0.9952
Epoch: 9  Loss: 0.0310  Train Acc: 0.9965
```

**测试集（10000 张）：**

| 指标 | 数值 |
|---|---|
| Accuracy | **0.9905** |
| Precision (weighted) | 0.9905 |
| Recall (weighted) | 0.9905 |
| F1 (weighted) | 0.9905 |
| Train Loss（第 1 轮 → 第 10 轮） | 0.3163 → 0.0310，**下降 90.2%** |
| 参数量 | 103,050 |

生成的文件都在 `result/stage_3_result/`：
- `CNN_MNIST_prediction_result_None` —— 预测结果 pickle（`pred_y` / `true_y` / `loss_history`）
- `CNN_MNIST_loss_history.txt` —— 每轮 loss
- `CNN_MNIST_loss_curve.png` —— 学习曲线图

---

## 接下来你自己做 ORL / CIFAR：改哪里

| 你要改的 | MNIST | ORL | CIFAR |
|---|---|---|---|
| `Dataset_Loader` 参数 | `channel=None, label_offset=0` | **`channel=0, label_offset=1`** | `channel=None, label_offset=0` |
| 输入形状 | `(N, 1, 28, 28)` | `(N, 1, 112, 92)` | `(N, 3, 32, 32)` |
| 第一层 `in_channels` | 1 | 1 | **3** |
| 输出类数 | 10 | **40** | 10 |
| 摊平后的维度 | 16×7×7 = 784 | **自己按公式算** | 自己算 |
| 训练样本数 | 60000 | **只有 360** ⚠️ | 50000 |
| 主要风险 | 无 | **严重过拟合** | 需要更深的网络 |

**ORL 的三个具体建议：**
1. 360 张训练图配 40 类，模型千万别做大。可以砍到 `conv(1→8)-pool-conv(8→16)-pool-fc`，全连接层小一点。
2. 加大 Dropout（0.5）、加 weight_decay，**一定要画训练/测试两条曲线**看有没有过拟合。
3. 标签减 1 别忘了（`label_offset=1`），否则 40 类的输出层遇到标签 40 会直接崩。

**CIFAR 的建议：**
1. 第一层 `in_channels=3`。
2. 32×32 的彩色图比 MNIST 难得多，两层卷积不太够，建议 3–4 层卷积 + 每层通道翻倍。
3. 可以加数据增强（随机水平翻转、随机裁剪）提升性能。

**3-5 消融实验怎么做（这是拉开分数的关键）：**
`method_obj` 上的这几个属性在脚本里就能改，**一次只改一个**，对比测试集 Accuracy：

```python
method_obj.learning_rate = 1e-3    # 1e-2 / 1e-3 / 1e-4
method_obj.batch_size = 128        # 32 / 128 / 512
method_obj.max_epoch = 10
method_obj.weight_decay = 1e-4
```

官方点名的消融维度：**模型深度、kernel size、padding、stride、pooling 类型、隐藏层维度、loss function**。
做一张表，一行一个变体，最后一列写测试集 Accuracy，再分析原因（比如 kernel 变大 → 感受野变大但参数变多；加深 → 要配 BatchNorm 否则梯度消失）。

---

## 报告（3-6）要包含的东西

最多 **5 页**，超了会扣分。按官方 report template 的结构写：

1. **实验设置**：数据集统计、模型结构（贴上面那张形状表最好）、超参数
2. **学习曲线**：三张图（MNIST / ORL / CIFAR）
3. **评估结果**：每个数据集一张指标表（Acc / P / R / F1）
4. **配置消融**：3-5 的对比表格 + 原因分析
5. **结论**：哪种配置最好、为什么

> Stage 2 的报告可以作为格式参考：`result/stage_2_result/Stage_2-5_Dasheng_Pan.pdf`

---

## 附：完整文件清单

**新写的**
- `local_code/stage_3_code/Dataset_Loader.py` —— pickle 版图像加载器（三个数据集通用）
- `local_code/stage_3_code/Method_CNN_MNIST.py` —— CNN 模型
- `local_code/stage_3_code/Evaluate_Metrics.py` —— Acc + P/R/F1
- `script/stage_3_script/script_cnn_mnist.py` —— 入口脚本
- `script/stage_3_script/plot_loss.py` —— 画学习曲线

**改写的**
- `local_code/stage_3_code/Setting_Train_Test_Split.py` —— 去掉 train_test_split

**复用没动的**
- `local_code/base_class/*.py` —— 五个基类
- `local_code/stage_3_code/Result_Saver.py` —— 存 pickle
- `local_code/stage_3_code/Evaluate_Accuracy.py` —— 单算 accuracy 的备用
