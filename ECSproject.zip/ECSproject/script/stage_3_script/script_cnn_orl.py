"""
Stage 3 入口脚本：ORL 人脸识别（CNN，40 类）。

运行方式（在 script/stage_3_script/ 目录下执行）：
    cd script/stage_3_script
    PYTHONPATH=../.. python3 script_cnn_orl.py
    PYTHONPATH=../.. python3 plot_loss_orl.py      # 画学习曲线

和 script_cnn_mnist.py 的结构完全一样，只有三处不同：
    ① Dataset_Loader 的参数   channel=0, label_offset=1
    ② 模型类                  Method_CNN_ORL
    ③ 结果输出路径            result/stage_3_result/CNN_ORL_*
"""

from local_code.stage_3_code.Dataset_Loader import Dataset_Loader
from local_code.stage_3_code.Method_CNN_ORL import Method_CNN_ORL
from local_code.stage_3_code.Result_Saver import Result_Saver
from local_code.stage_3_code.Setting_Train_Test_Split import Setting_Train_Test_Split
from local_code.stage_3_code.Evaluate_Metrics import Evaluate_Metrics

import numpy as np
import torch

if __name__ == '__main__':
    # 固定随机种子，保证结果可复现
    np.random.seed(2)
    torch.manual_seed(2)

    # ---- 1. 数据 ----
    # ORL 的三个关键参数：
    #   channel=0      ORL 是灰度图复制成三份 RGB，只取第 0 个通道就够
    #   label_offset=1 ORL 标签是 1~40，减 1 变成 0~39（CrossEntropyLoss 要求）
    data_obj = Dataset_Loader('orl-cnn', 'ORL faces, 40 classes, 360 train / 40 test',
                              channel=0, label_offset=1)
    data_obj.dataset_source_folder_path = '../../data/stage_3_data/'
    data_obj.dataset_source_file_name = 'ORL'

    # ---- 2. 模型 ----
    # inputchannel=1（灰度单通道），nclass=40（40 个人）
    method_obj = Method_CNN_ORL('cnn-orl',
                                'conv(1-10-10-24)-bn-relu-pool x3 -> gap -> fc(24-40)',
                                inputchannel=1, nclass=40)
    # 3-5 消融实验改这几行（一次只改一个）：
    # method_obj.learning_rate = 1e-3
    # method_obj.batch_size = 16
    # method_obj.max_epoch = 30
    # method_obj.weight_decay = 1e-3

    # ---- 3. 结果保存 ----
    result_obj = Result_Saver('saver', '')
    result_obj.result_destination_folder_path = '../../result/stage_3_result/CNN_ORL_'
    result_obj.result_destination_file_name = 'prediction_result'

    # ---- 4. 指标 ----
    evaluate_obj = Evaluate_Metrics('accuracy + weighted P/R/F1', '')

    # ---- 5. 串起来跑 ----
    setting_obj = Setting_Train_Test_Split('teacher-provided train/test', '')
    setting_obj.prepare(data_obj, method_obj, result_obj, evaluate_obj)
    setting_obj.print_setup_summary()

    print('************ Start ************')
    score, _ = setting_obj.load_run_save_evaluate()

    # ---- 6. 存 loss 曲线 ----
    curve_path = '../../result/stage_3_result/CNN_ORL_loss_history.txt'
    with open(curve_path, 'w') as handle:
        for epoch, loss in enumerate(method_obj.last_history):
            handle.write('%d,%.6f\n' % (epoch, loss))
    print('loss 曲线已写到', curve_path)

    print('************ Overall Performance ************')
    print('Test  Accuracy: %.4f' % score['accuracy'])
    print('      Precision: %.4f  Recall: %.4f  F1: %.4f' % (
        score['precision'], score['recall'], score['f1'],
    ))
    print('************ Finish ************')
