"""
Stage 3 入口脚本：MNIST 手写数字识别（CNN）。

运行方式（在 script/stage_3_script/ 目录下执行）：
    cd script/stage_3_script
    PYTHONPATH=../.. python3 script_cnn_mnist.py

它做四件事，和 Stage 1/2 的脚本一模一样：
    1. 建对象   —— 建五个组件（data / method / result / setting / evaluate）的对象
    2. 装参数   —— 给每个对象填路径、名字、超参
    3. 串起来跑 —— setting.prepare(...) 把五个对象装在一起，然后 load_run_save_evaluate()
    4. 存曲线   —— 把每轮 loss 存成文本，报告里画学习曲线用

================================================================================
五件套是怎么串起来的（报告里要画的架构图就是这个）
================================================================================
    Dataset_Loader  读数据         ->  method.data
    Method_CNN      train / test   ->  预测结果 dict
    Result_Saver     存 pickle
    Evaluate_Metrics 算指标
    Setting          数据流向 + 训练/测试划分 + 把它们串起来

数据集和模型是「解耦」的：换数据集只改脚本里的 Dataset_Loader 参数，
换模型只改 method 那一行。这就是老师强调的模板架构的意义。

================================================================================
要做 ORL / CIFAR 怎么办
================================================================================
把这个脚本复制成 script_cnn_orl.py / script_cnn_cifar.py，改三处：
    ① Dataset_Loader 的参数（见下面注释里的三行对照）
    ② Method_CNN_XXX（换成你自己的模型类）
    ③ result 的输出路径（别覆盖 MNIST 的结果）
"""

from local_code.stage_3_code.Dataset_Loader import Dataset_Loader
from local_code.stage_3_code.Method_CNN_CIFAR import Method_CNN_MNIST
from local_code.stage_3_code.Result_Saver import Result_Saver
from local_code.stage_3_code.Setting_Train_Test_Split import Setting_Train_Test_Split
from local_code.stage_3_code.Evaluate_Metrics import Evaluate_Metrics

import numpy as np
import torch

if __name__ == '__main__':
    # ---- 0. 固定随机种子：同一个种子跑两次结果一样，报告里的数字才可复现 ----
    np.random.seed(2)
    torch.manual_seed(2)

    # ---- 1. 数据 ----
    # 三个数据集的参数对照（Stage 3-1 要求）：
    #   MNIST: file_name='MNIST', channel=None, label_offset=0   <- 本脚本
    #   ORL  : file_name='ORL',   channel=0,    label_offset=1   (标签 1~40 要减 1)
    #   CIFAR: file_name='CIFAR', channel=None, label_offset=0
    data_obj = Dataset_Loader('CIFAR-cnn', 'MNIST 60k train / 10k test, 28x28 gray')
    data_obj.dataset_source_folder_path = '../../data/stage_3_data/'
    data_obj.dataset_source_file_name = 'CIFAR'
    # flatten=False 是关键：CNN 要 (N,1,28,28) 四维，不要平铺的 (N,784)

    # ---- 2. 模型 ----
    # 名字里把结构写清楚，报告表格里直接用
    method_obj = Method_CNN_MNIST('CIFAR-mnist', 'conv(1-8)-pool-conv(8-16)-bn-pool-fc(784-128-10)')
    # 3-5 消融实验就改这几行（一次只改一个）：
    method_obj.learning_rate = 1e-3
    method_obj.batch_size = 128
    method_obj.max_epoch = 10

    # ---- 3. 结果保存 ----
    result_obj = Result_Saver('saver', '')
    result_obj.result_destination_folder_path = '../../result/stage_3_result/CNN_CIFAR_'
    result_obj.result_destination_file_name = 'prediction_result'

    # ---- 4. 指标 ----
    evaluate_obj = Evaluate_Metrics('accuracy + weighted P/R/F1', '')

    # ---- 5. 串起来跑 ----
    setting_obj = Setting_Train_Test_Split('teacher-provided train/test', '')
    setting_obj.prepare(data_obj, method_obj, result_obj, evaluate_obj)
    setting_obj.print_setup_summary()

    print('************ Start ************')
    score, _ = setting_obj.load_run_save_evaluate()

    # ---- 6. 把每轮 loss 存成文本，报告里画学习曲线用 ----
    curve_path = '../../result/stage_3_result/CNN_CIFAR_loss_history.txt'
    with open(curve_path, 'w') as handle:
        for epoch, loss in enumerate(method_obj.last_history):
            handle.write('%d,%.6f\n' % (epoch, loss))
    print('loss 曲线已写到', curve_path)

    print('************ Overall Performance ************')
    print('Accuracy: %.4f' % score['accuracy'])
    print('Precision: %.4f  Recall: %.4f  F1: %.4f' % (
        score['precision'], score['recall'], score['f1'],
    ))
    print('************ Finish ************')
