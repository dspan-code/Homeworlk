"""
把 result/stage_3_result/CNN_MNIST_loss_history.txt 画成学习曲线。

运行方式（在 script/stage_3_script/ 目录下执行）：
    cd script/stage_3_script
    PYTHONPATH=../.. python3 plot_loss.py

生成的图存到 result/stage_3_result/CNN_MNIST_loss_curve.png，
报告里的「learning curve」那一张图就是它。

================================================================================
报告里这张图该怎么解读（3-3 要求 "Generate the learning curves"）
================================================================================
· 横轴 epoch、纵轴 training loss。
· 正常的样子：前几轮掉得很快（模型在快速学「这是几」的大轮廓），
  后面越来越平（学到了细节，边际收益变小）。
· 如果 loss 一直不降 -> 学习率太小，或者代码有 bug（比如忘了 zero_grad）。
· 如果 loss 突然变成 nan -> 学习率太大，梯度爆了。
· 想要更完整的「学习曲线」，可以再加一条测试集 accuracy 曲线，
  这样能看出「训练集继续涨、测试集开始跌」这个过拟合信号。
  ——MNIST 上一般不会过拟合，10 万参数对 6 万张图不算多；
    但 ORL 只有 360 张训练图、40 类，过拟合会非常明显，一定要画两条。
"""

import matplotlib
# 服务器/无显示环境下用 Agg 后端（不弹窗，只存文件）
matplotlib.use('Agg')
from matplotlib import pyplot as plt

# ---- 1. 读 loss 记录 ----
csv_path = '../../result/stage_3_result/CNN_MNIST_loss_history.txt'
png_path = '../../result/stage_3_result/CNN_MNIST_loss_curve.png'

epochs, losses = [], []
with open(csv_path, 'r') as handle:
    for line in handle:
        line = line.strip()
        if not line:
            continue
        epoch, loss = line.split(',')
        epochs.append(int(epoch))
        losses.append(float(loss))

# ---- 2. 画图 ----
plt.figure(figsize=(7, 4.5))
plt.plot(epochs, losses, marker='o', markersize=4, linewidth=1.8, color='#2f5597')
plt.xlabel('Epoch')
plt.ylabel('Training Loss (cross-entropy)')
plt.title('MNIST CNN — Training Loss Curve')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(png_path, dpi=150)
print('图已保存到', png_path)

# ---- 3. 顺手把关键数字打印出来，写报告时直接抄 ----
print('第一轮 loss: %.4f' % losses[0])
print('最后一轮 loss: %.4f' % losses[-1])
print('下降了 %.1f%%' % ((losses[0] - losses[-1]) / losses[0] * 100))
