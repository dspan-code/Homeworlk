"""
把 ORL 的 loss 记录画成学习曲线。

运行方式（在 script/stage_3_script/ 目录下执行）：
    cd script/stage_3_script
    PYTHONPATH=../.. python3 plot_loss_orl.py

生成的图存到 result/stage_3_result/CNN_ORL_loss_curve.png

================================================================================
报告里怎么解读这张图（3-3 / 3-4 要求 "Generate the learning curves"）
================================================================================
· 横轴 epoch、纵轴 training loss（交叉熵）
· 正常形状：前几轮掉得快，后面越来越平
· 如果 loss 一直不降 -> 学习率太小，或者模型容量不够（ORL 上很容易遇到）
· 如果 loss 变 nan   -> 学习率太大
· ORL 只有 360 张训练图、40 类，**只看 loss 不够**，一定要把训练集/测试集
  两条准确率曲线放一起看：
    - 两条都高且接近  -> 正常
    - 训练高、测试低  -> 过拟合（ORL 上这是主要风险）
"""

import matplotlib
matplotlib.use('Agg')          # 无显示环境也能跑，只存文件
from matplotlib import pyplot as plt

csv_path = '../../result/stage_3_result/CNN_ORL_loss_history.txt'
png_path = '../../result/stage_3_result/CNN_ORL_loss_curve.png'

epochs, losses = [], []
with open(csv_path, 'r') as handle:
    for line in handle:
        line = line.strip()
        if not line:
            continue
        epoch, loss = line.split(',')
        epochs.append(int(epoch))
        losses.append(float(loss))

plt.figure(figsize=(7, 4.5))
plt.plot(epochs, losses, marker='o', markersize=4, linewidth=1.8, color='#2f5597')
plt.xlabel('Epoch')
plt.ylabel('Training Loss (cross-entropy)')
plt.title('ORL CNN — Training Loss Curve')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(png_path, dpi=150)
print('图已保存到', png_path)

print('第一轮 loss: %.4f' % losses[0])
print('最后一轮 loss: %.4f' % losses[-1])
print('下降了 %.1f%%' % ((losses[0] - losses[-1]) / losses[0] * 100))
