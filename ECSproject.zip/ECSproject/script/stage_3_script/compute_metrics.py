"""
一次算出三个数据集的所有评估指标，直接输出成报告可用的表格。

运行方式（在 script/stage_3_script/ 目录下执行）：
    cd script/stage_3_script
    PYTHONPATH=../.. python3 compute_metrics.py

输出：
    1. 总体指标表（Accuracy / Precision / Recall / F1）
    2. 每个数据集的分类报告（每类的 P/R/F1）
    3. 直接可复制的 markdown 表格

================================================================================
为什么用 weighted 而不是 macro
================================================================================
多分类的 P/R/F1 需要指定汇总方式：
  · 'macro'    每类各算一个，然后直接平均 -> 小类权重被放大
  · 'weighted' 每类各算一个，按样本数加权平均 -> 更接近整体准确率
  · 'micro'    所有类汇总后计算 -> 单标签多分类下等价于 accuracy，重复
本脚本主表用 weighted，同时打印 macro 供对比。
"""

import os
import pickle
import numpy as np
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, classification_report)

RESULT_DIR = '../../result/stage_3_result'

# CIFAR-10 的类别名（打印分类报告时用）
CIFAR_NAMES = ['airplane', 'automobile', 'bird', 'cat', 'deer',
               'dog', 'frog', 'horse', 'ship', 'truck']


def evaluate(name):
    path = os.path.join(RESULT_DIR, 'CNN_%s_prediction_result_None' % name)
    if not os.path.exists(path):
        print('[跳过] %s: 找不到 %s' % (name, path))
        return None

    with open(path, 'rb') as f:
        d = pickle.load(f)

    y_true = np.asarray(d['true_y'])
    y_pred = np.asarray(d['pred_y'])

    return {
        'name': name,
        'n': len(y_true),
        'accuracy':  accuracy_score(y_true, y_pred),
        'precision': precision_score(y_true, y_pred, average='weighted', zero_division=0),
        'recall':    recall_score(y_true, y_pred, average='weighted', zero_division=0),
        'f1':        f1_score(y_true, y_pred, average='weighted', zero_division=0),
        'f1_macro':  f1_score(y_true, y_pred, average='macro', zero_division=0),
        'report':    classification_report(
                         y_true, y_pred,
                         target_names=CIFAR_NAMES if name == 'CIFAR' else None,
                         zero_division=0, digits=3),
        'y_true': y_true, 'y_pred': y_pred,
    }


if __name__ == '__main__':
    results = [r for r in (evaluate(n) for n in ['MNIST', 'ORL', 'CIFAR']) if r]

    # ---- 1. 总体指标表 ----
    print('=' * 92)
    print('%-8s %8s %10s %10s %10s %10s %10s'
          % ('数据集', '样本数', 'Accuracy', 'Precision', 'Recall', 'F1(w)', 'F1(macro)'))
    print('=' * 92)
    for r in results:
        print('%-8s %8d %10.4f %10.4f %10.4f %10.4f %10.4f'
              % (r['name'], r['n'], r['accuracy'], r['precision'],
                 r['recall'], r['f1'], r['f1_macro']))
    print('=' * 92)

    # ---- 2. 每个数据集的分类报告 ----
    for r in results:
        print('\n%s 分类报告:' % r['name'])
        print(r['report'])

    # ---- 3. markdown 表格 ----
    print('\n' + '=' * 92)
    print('markdown（复制进报告）:')
    print()
    print('| 数据集 | 测试样本数 | Accuracy | Precision | Recall | F1 (weighted) |')
    print('|---|---|---|---|---|---|')
    for r in results:
        print('| %s | %d | %.4f | %.4f | %.4f | %.4f |'
              % (r['name'], r['n'], r['accuracy'], r['precision'],
                 r['recall'], r['f1']))

    # ---- 4. 找出每个数据集最难分的类别 ----
    print('\n' + '=' * 92)
    print('各数据集最难区分的类别（F1 最低）:')
    for r in results:
        from sklearn.metrics import f1_score as f1s
        labels = np.unique(r['y_true'])
        per_class = f1s(r['y_true'], r['y_pred'], average=None, zero_division=0)
        order = np.argsort(per_class)
        worst = [(labels[i], per_class[i]) for i in order[:3]]
        if r['name'] == 'CIFAR':
            worst = [(CIFAR_NAMES[labels[i]], per_class[i]) for i in order[:3]]
        print('  %-6s %s' % (r['name'], ['%s(%.3f)' % (w[0], w[1]) for w in worst]))
