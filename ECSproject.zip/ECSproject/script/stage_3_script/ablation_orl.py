"""
Stage 3-5 消融实验（ORL）：一次只改一个变量，看对准确率的影响。

运行方式（在 script/stage_3_script/ 目录下执行）：
    cd script/stage_3_script
    PYTHONPATH=../.. python3 ablation_orl.py

================================================================================
实验设计
================================================================================
官方 3-5 点名的消融维度：
    · 模型深度（几层卷积）
    · kernel size
    · padding
    · stride
    · pooling 层类型
    · 隐藏层维度
    · loss function

全部实验都遵循「控制变量」原则：改一个，其余保持基准值不变。
基准配置（baseline）见 BASELINE，每组实验只覆盖其中一两个字段。

参数控制：所有配置都刻意做得很小（总参数 < 5 万），
因为 ORL 只有 360 张训练图，参数越多越容易过拟合。

================================================================================
怎么读结果
================================================================================
每个配置跑 3 个随机种子取平均，避免单次运气影响结论。
输出格式：
    CFG <组名> | <配置描述> | mean=0.xxx [seed结果...] | 参数=xxxx

写报告时把每组的结果整理成表格，一列一个变量，说明「变了什么 → 准确率怎么变 → 为什么」。
"""

import numpy as np
import torch
import torch.nn as nn
from torch import nn as _nn

from local_code.stage_3_code.Dataset_Loader import Dataset_Loader


# =============================================================================
# 可配置的通用 CNN —— 所有消融都在这个类上改参数
# =============================================================================
class ConfigurableCNN(nn.Module):
    """
    一个参数化的 CNN，所有结构细节都由 __init__ 的参数决定。
    这样可以一次测完所有消融组合，不用写 N 个类。
    """

    def __init__(self,
                 in_channels=1,       # 输入通道：ORL 用 1
                 nclass=40,           # 输出类别数
                 channels=(32, 64, 128),  # 每层输出通道
                 kernels=(3, 3, 3),   # 每层 kernel size
                 strides=(1, 1, 1),   # 每层 stride
                 paddings=None,       # None = 自动算 same padding
                 pools=(2, 2, 2),     # 每层池化核；None 表示该层不池化
                 pool_type='max',     # 'max' 或 'avg'
                 dropout=0.5,         # 分类头 dropout
                 head_hidden=None,    # 分类头中间层维度；None = 单层 Linear
                 use_bn=True,         # 是否用 BatchNorm
                 ):
        super().__init__()
        assert len(channels) == len(kernels) == len(strides) == len(pools)

        # ---- 自动推导 same padding ----
        if paddings is None:
            paddings = [((k - 1) * s) // 2 for k, s in zip(kernels, strides)]

        # ---- 卷积部分 ----
        layers = []
        c_in = in_channels
        for i, (c_out, k, s, p) in enumerate(zip(channels, kernels, strides, paddings)):
            layers.append(nn.Conv2d(c_in, c_out, k, stride=s, padding=p, bias=not use_bn))
            if use_bn:
                layers.append(nn.BatchNorm2d(c_out))
            layers.append(nn.ReLU())
            if pools[i] is not None:
                if pool_type == 'max':
                    layers.append(nn.MaxPool2d(pools[i]))
                else:
                    layers.append(nn.AvgPool2d(pools[i]))
            c_in = c_out
        self.features = nn.Sequential(*layers)

        # ---- 分类头 ----
        # 全局平均池化 → 通道数维度 → 全连接
        head = [nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Dropout(dropout)]
        if head_hidden is not None:
            head += [nn.Linear(c_in, head_hidden), nn.ReLU(), nn.Dropout(dropout),
                     nn.Linear(head_hidden, nclass)]
        else:
            head += [nn.Linear(c_in, nclass)]
        self.classifier = nn.Sequential(*head)

    def forward(self, x):
        return self.classifier(self.features(x))


# =============================================================================
# 训练 / 评估（简洁版，只为本消融服务）
# =============================================================================
def train_and_eval(cfg, data, seed, epochs=40, lr=1e-3, bs=16, wd=1e-4,
                   loss_name='ce', optimizer_name='adam', device=None):
    torch.manual_seed(seed)
    np.random.seed(seed)
    if device is None:
        device = torch.device('mps') if torch.backends.mps.is_available() else torch.device('cpu')

    # ---- 数据 ----
    X_tr = np.asarray(data['train']['X'], dtype=np.float32)
    y_tr = np.asarray(data['train']['y'], dtype=np.int64)
    X_te = np.asarray(data['test']['X'], dtype=np.float32)
    y_te = np.asarray(data['test']['y'], dtype=np.int64)

    # 标准化（用训练集统计量）
    mean, std = float(X_tr.mean()), float(X_tr.std())
    X_tr = (X_tr - mean) / std
    X_te = (X_te - mean) / std

    Xt = torch.FloatTensor(X_tr).to(device)
    yt = torch.LongTensor(y_tr).to(device)
    Xe = torch.FloatTensor(X_te).to(device)

    # ---- 模型 ----
    model = ConfigurableCNN(**cfg).to(device)

    # ---- loss ----
    if loss_name == 'ce':
        loss_fn = nn.CrossEntropyLoss()
    elif loss_name == 'nll':        # cross entropy 拆成 log_softmax + NLL
        loss_fn = None
    elif loss_name == 'mse':        # 把标签转成 one-hot，用 MSE
        loss_fn = None
    else:
        raise ValueError(loss_name)

    # ---- optimizer ----
    if optimizer_name == 'adam':
        opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=wd)
    elif optimizer_name == 'sgd':
        opt = torch.optim.SGD(model.parameters(), lr=lr * 10, momentum=0.9, weight_decay=wd)
    else:
        raise ValueError(optimizer_name)

    # ---- 训练循环 ----
    for epoch in range(epochs):
        model.train()
        order = torch.randperm(len(Xt), device=device)
        for start in range(0, len(Xt), bs):
            idx = order[start:start + bs]
            xb, yb = Xt[idx], yt[idx]

            logits = model(xb)
            if loss_name == 'ce':
                loss = loss_fn(logits, yb)
            elif loss_name == 'nll':
                loss = nn.functional.nll_loss(nn.functional.log_softmax(logits, dim=1), yb)
            else:  # mse
                onehot = nn.functional.one_hot(yb, cfg['nclass']).float()
                loss = nn.functional.mse_loss(torch.softmax(logits, dim=1), onehot)

            opt.zero_grad()
            loss.backward()
            opt.step()

    # ---- 测试 ----
    model.eval()
    with torch.no_grad():
        pred = model(Xe).argmax(dim=1).cpu().numpy()
    acc = float((pred == y_te).mean())
    n_params = sum(p.numel() for p in model.parameters())
    return acc, n_params


# =============================================================================
# 主实验
# =============================================================================
if __name__ == '__main__':
    loader = Dataset_Loader('orl', '', channel=0, label_offset=1)
    loader.dataset_source_folder_path = '../../data/stage_3_data/'
    loader.dataset_source_file_name = 'ORL'
    data = loader.load()

    SEEDS = [1, 2, 3]
    EPOCHS = 40

    def run(tag, cfg, **train_kw):
        accs, n_params = [], None
        for s in SEEDS:
            a, p = train_and_eval(cfg, data, s, epochs=EPOCHS, **train_kw)
            accs.append(a)
            n_params = p
        print('CFG %-28s mean=%.3f  %-22s 参数=%d'
              % (tag, float(np.mean(accs)), str([round(a, 3) for a in accs]), n_params),
              flush=True)
        return float(np.mean(accs))

    # ---- 基准配置 ----
    BASELINE = dict(
        in_channels=1, nclass=40,
        channels=(8, 16, 32),       # 刻意做小：参数少，适合 360 张图
        kernels=(3, 3, 3),
        strides=(1, 1, 1),
        pools=(2, 2, 2),
        pool_type='max',
        dropout=0.5,
        head_hidden=None,
        use_bn=True,
    )
    print('=' * 100)
    print('基准配置 baseline:', BASELINE)
    print('=' * 100)
    run('baseline', BASELINE)

    # =========================================================================
    # 组 1：dropout 比例
    # =========================================================================
    print('\n--- 组1: dropout 比例 ---')
    for d in [0.0, 0.2, 0.3, 0.5, 0.7]:
        run('dropout=%.1f' % d, dict(BASELINE, dropout=d))

    # =========================================================================
    # 组 2：卷积层数（2 / 3 / 4 层）
    # =========================================================================
    print('\n--- 组2: 卷积层数 ---')
    run('2层 ch=(16,32)',
        dict(BASELINE, channels=(16, 32), kernels=(3, 3), strides=(1, 1), pools=(2, 2)))
    run('3层 ch=(8,16,32) [baseline]', BASELINE)
    run('4层 ch=(8,16,32,64)',
        dict(BASELINE, channels=(8, 16, 32, 64), kernels=(3,)*4, strides=(1,)*4, pools=(2,)*4))

    # =========================================================================
    # 组 3：kernel size（2~6）+ 对应的 same padding
    # =========================================================================
    print('\n--- 组3: kernel size ---')
    for k in [2, 3, 4, 5, 6]:
        run('kernel=%d' % k, dict(BASELINE, kernels=(k, k, k)))

    # =========================================================================
    # 组 4：stride（1~4），同时去掉池化，避免双重降维
    # =========================================================================
    print('\n--- 组4: stride ---')
    for s in [1, 2, 3, 4]:
        if s == 1:
            run('stride=1 + pool2 [baseline]', dict(BASELINE, strides=(1, 1, 1), pools=(2, 2, 2)))
        else:
            run('stride=%d (no pool)' % s,
                dict(BASELINE, strides=(s, s, s), pools=(None, None, None)))

    # =========================================================================
    # 组 5：pooling 类型与大小
    # =========================================================================
    print('\n--- 组5: pooling ---')
    run('maxpool 2 (baseline)', dict(BASELINE, pool_type='max', pools=(2, 2, 2)))
    run('avgpool 2', dict(BASELINE, pool_type='avg', pools=(2, 2, 2)))
    run('maxpool 3', dict(BASELINE, pool_type='max', pools=(3, 3, 3)))
    run('无池化 (only conv)', dict(BASELINE, pools=(None, None, None)))

    # =========================================================================
    # 组 6：分类头隐藏层维度
    # =========================================================================
    print('\n--- 组6: 隐藏层维度 ---')
    run('head 单层 (baseline)', dict(BASELINE, head_hidden=None))
    for h in [16, 32, 64]:
        run('head hidden=%d' % h, dict(BASELINE, head_hidden=h))

    # =========================================================================
    # 组 7：loss function
    # =========================================================================
    print('\n--- 组7: loss function ---')
    run('CrossEntropy (baseline)', BASELINE, loss_name='ce')
    run('NLL + log_softmax', BASELINE, loss_name='nll')
    run('MSE + softmax', BASELINE, loss_name='mse')

    # =========================================================================
    # 组 8：optimizer 与 BatchNorm
    # =========================================================================
    print('\n--- 组8: optimizer / BatchNorm ---')
    run('Adam (baseline)', BASELINE, optimizer_name='adam')
    run('SGD momentum=0.9', BASELINE, optimizer_name='sgd')
    run('无 BatchNorm', dict(BASELINE, use_bn=False))

    print('\n全部实验完成。')
